# Personal Expense & Budget Tracking System

A full-stack personal finance web application built from the six-module capstone specification—delivering private user accounts, income and expense ledgers, automated budget alerts, visual analytics, personalisation, recurring bills, savings goals, and spending predictions.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The architectural choices below reflect your Phase 1 selections and establish the defaults for building the working model.

- **Confirmed Decision 1 (Authentication & Storage)**: Local Express server using email and password registration/login, salted password hashing, HTTP-only session cookies, and structured local file persistence with strict per-user record isolation.
- **Confirmed Decision 2 (Currency & Display Mode)**: Starts in **INR (`₹`)** with a persistent **Light / Dark theme** toggle saved per user account, alongside support for switching to USD (`$`), EUR (`€`), or GBP (`£`).
- **Confirmed Decision 3 (Future Scope Additions)**: Includes **Recurring Expenses & Bills**, **Savings Goals Tracker**, and **Smart Spending Insights & Predictions** integrated alongside the six core modules.
- **Recommended Enhancement (Seeded Demo Access)**: Alongside full account registration, the login screen will include a one-click demo sign-in option pre-populated with realistic multi-month sample transactions so you can inspect charts, budget warnings, and spending forecasts immediately.

---

### 1. Overview & Core Concept

- **What It Does**: Replaces manual notebooks and spreadsheets with a unified personal finance workspace where individuals register private accounts, log income and daily expenses, enforce monthly and category-level spending caps, monitor visual trends, manage recurring bills, track savings targets, and receive proactive spending forecasts.
- **Target Audience / Persona**: Students, young professionals, and individuals managing monthly allowances, salaries, part-time income, and multi-category household or academic expenses.
- **Key Value**: Centralises income, expenditure, budget limits, and predictive insights into one responsive dashboard—calculating available balance, remaining budget, 80% warning thresholds, and >100% overrun alerts automatically whenever records change.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Onboarding & Authentication**: Unauthenticated visitors land on a clean split-panel sign-in and registration view (Name, Email, Password) with inline validation and an optional pre-filled demo sign-in action. Upon authentication, the server loads the user's saved theme, currency, and financial ledger.
  2. **Dashboard Overview**: Authenticated users enter a workspace featuring a fixed left navigation sidebar (`Overview`, `Income`, `Expenses`, `Budgets & Goals`, `Reports & Insights`, `Settings & Profile`), a top contextual header with month selector (`Month` + `Go`), theme switcher, and user sign-out, and a scannable main viewport.
  3. **Quick Transaction & Budget Loop**: Users log expenses (amount, category, payment method, optional note, date) or income (amount, source, description, date) directly from the dashboard or dedicated ledger views. Every addition, edit, or deletion immediately updates KPI summaries, category budget progress bars, 80%/100% alert banners, and charts.
  4. **Recurring Bills, Goals & Insights**: Users schedule recurring bills (with one-click "Log for Current Month" actions), allocate funds toward named savings goals, and review data-driven spending predictions comparing current burn rate against prior months.
  5. **Personalisation & Profile**: Users switch currency (`INR`, `USD`, `EUR`, `GBP`), toggle Light/Dark mode, add/remove custom expense categories, adjust overall and category monthly limits, and update their profile name or password.

- **Visual Identity & Theme**:
  - **Aesthetic Direction**: Refined, high-clarity financial utility—single-elevation surfaces separated by crisp 1px hairline borders, generous whitespace, and zero ornamental clutter or pill-badge noise.
  - **Color Palette & Mood (60-30-10 Rule)**:
    - *Light Mode*: `#F8FAFC` neutral canvas (60%), `#FFFFFF` structural cards with `#E2E8F0` hairline borders (30%), `#1D4ED8` crisp cobalt primary actions (10%).
    - *Dark Mode*: `#0F172A` deep slate canvas (60%), `#1E293B` elevated slate surfaces with `#334155` hairline borders (30%), `#3B82F6` luminous blue primary actions (10%).
    - *Semantic Status Colors (Always paired with explicit text labels)*: Emerald (`#16A34A`) for healthy budget / savings on track; Amber (`#D97706`) for the **80% Budget Warning**; Crimson (`#DC2626`) for **Exceeded Budget (>100%)** alerts.
  - **Typography & Hierarchy**: `Plus Jakarta Sans` for headings and navigation, `DM Sans` for body copy and forms, and `JetBrains Mono` with `tabular-nums` on every currency figure, percentage, date, and table column so decimals align vertically.
  - **Component Styling & Layout**: `240px–260px` desktop sidebar (collapsing to a clean drawer on mobile) + 3-zone top header (`Page Breadcrumb` — `Month Filter` — `Theme Toggle & Sign Out`). High-density transaction tables (`40px` row height, left-aligned text, right-aligned tabular amounts), interactive SVG/Canvas Donut and Bar charts, and explicit empty, loading, and validation states.
  - **Interactive Feedback & Motion**: Subtle 150ms–200ms opacity/transform transitions for modal drawers, inline row edits, and toast confirmations respecting `prefers-reduced-motion`.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 (Backend Persistence Architecture)**:
  - *Chosen Approach*: Full-stack Express server running alongside Vite, persisting per-user encrypted accounts and financial collections in structured local JSON data files on disk.
  - *Why*: Directly honours your selection of local server email/password authentication while mirroring the capstone presentation's file-handling persistence model without requiring external cloud databases or manual configuration.
  - *Alternatives Considered*: Browser `localStorage` (rejected because records wouldn't survive across browsers or enforce true server-side session checks) and PostgreSQL/Cloud SQL (unnecessary operational weight for single-node local persistence).

- **Decision 2 (Deterministic Insights & Forecasting Engine)**:
  - *Chosen Approach*: Algorithmic time-series analysis on historical transactions (month-over-month category delta detection, daily burn-rate projection for the active month, and 3-month weighted moving average estimates).
  - *Why*: Produces instantaneous, reproducible, mathematically verifiable predictions and anomaly callouts with zero external API latency or key dependencies.
  - *Alternatives Considered*: External LLM API calls for insights (adds latency, external dependency, and cost for purely arithmetic forecasting).

- **Decision 3 (Server-Enforced User Data Separation)**:
  - *Chosen Approach*: HTTP-only HMAC-signed session cookies validated by authentication middleware on every `/api/*` endpoint, filtering all reads, writes, and deletes by the authenticated `userId`.
  - *Why*: Fulfils Module 1's strict privacy and data-isolation requirement so no user can view or mutate another user's income, expenses, budgets, or settings.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

#### Architecture & Component Diagram

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                         Client Workspace (React)                        │
│  ┌──────────────┐   ┌────────────────────────────────────────────────┐  │
│  │ Auth Screen  │   │ Protected Shell (Sidebar + Top Header + Theme) │  │
│  │ Sign In /    │   ├──────────────────┬─────────────────────────────┤  │
│  │ Register     │   │ Overview &       │ Management Modules          │  │
│  └──────┬───────┘   │ Analytics        │ - Income & Expense Ledgers  │  │
│         │           │ - KPI Strip      │ - Budget & Category Limits  │  │
│         │           │ - Donut & Bar    │ - Recurring Bills           │  │
│         │           │   Charts         │ - Savings Goals             │  │
│         │           │ - Smart Insights │ - Personalisation & Profile │  │
│         │           └────────┬─────────┴──────────────┬──────────────┘  │
└─────────┼────────────────────┼────────────────────────┼─────────────────┘
          │                    │ HTTP / JSON + Session  │
          ▼                    ▼                        ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    Express API & Session Middleware                     │
│  ┌────────────────┐  ┌──────────────────────┐  ┌─────────────────────┐  │
│  │ Auth & Profile │  │ Transaction & Budget │  │ Analytics & Forecast│  │
│  │ Scrypt + HMAC  │  │ CRUD + 80%/100% Eval │  │ Reports + Insights  │  │
│  └───────┬────────┘  └──────────┬───────────┘  └──────────┬──────────┘  │
│          └──────────────────────┼─────────────────────────┘             │
│                                 ▼                                       │
│                   Atomic Local JSON File Store (per User ID)            │
└─────────────────────────────────────────────────────────────────────────┘
```

#### Data Model & State

- **User Account**: `id`, `name`, `email`, `passwordHash` (`scrypt` salt + hash), `createdAt`.
- **User Preferences**: `userId`, `currency` (`INR` | `USD` | `EUR` | `GBP`), `theme` (`light` | `dark`), `monthlyBudget`, `categoryLimits` (key-value map), `customCategories` (string array).
- **Income Record**: `id`, `userId`, `amount`, `source` (`Salary`, `Allowance`, `Part-time`, `Gifts`, `Other`), `description`, `date` (`YYYY-MM-DD`).
- **Expense Record**: `id`, `userId`, `amount`, `category` (default + custom categories), `paymentMethod` (`UPI`, `Card`, `Cash`, `Net Banking`, `Other`), `note`, `date` (`YYYY-MM-DD`), optional `recurringId`.
- **Recurring Rule**: `id`, `userId`, `title`, `amount`, `category`, `paymentMethod`, `frequency` (`weekly` | `monthly` | `yearly`), `nextDueDate`, `active`, `lastLoggedMonth`.
- **Savings Goal**: `id`, `userId`, `title`, `targetAmount`, `savedAmount`, `deadline`, `createdAt`.

#### Interactive Component & State Mapping

- **Authentication Flow**: Submitting registration or login validates inputs client-side and sends credentials to the auth endpoint; successful responses set an HTTP-only session cookie and hydrate the React `AuthContext` with the user profile and saved preferences (`theme`, `currency`).
- **Transaction & Filter State**: Selecting a month in the top bar or entering search/category/payment filters updates query parameters and re-computes `calculateIncome()`, `calculateExpense()`, `calculateBalance()`, category totals, and budget usage percentages reactively.
- **Budget Alert Engine**: Both overall monthly spending and individual category totals evaluate `spent / limit`:
  - `>= 80%` and `<= 100%` triggers an Amber `"Approaching Limit (80%+)"` warning state.
  - `> 100%` triggers a Crimson `"Budget Exceeded (>100%)"` alert banner and highlights the offending category row.
- **Recurring Bills & Savings Goals**: Clicking `"Log Now"` on a due recurring rule creates an expense entry for the selected date and advances `nextDueDate`; clicking `"Add Funds"` on a savings goal updates `savedAmount` and recalculates progress percentage.
- **Reports & Smart Insights**: Toggling `Daily`, `Monthly`, or `Yearly` report tabs dynamically aggregates historical records into the comparison bar chart, identifies categories with month-over-month spending increases, and projects end-of-month total spend.
- **Personalisation Persistence**: Toggling Light/Dark mode immediately applies `.dark` on `document.documentElement` while persisting the preference to the user's backend profile so it restores automatically on future logins.
