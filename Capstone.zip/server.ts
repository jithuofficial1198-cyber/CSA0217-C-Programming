import express, { type Request, type Response, type NextFunction } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

type CurrencyCode = 'INR' | 'USD' | 'EUR' | 'GBP';
type ThemeMode = 'light' | 'dark';
type RecurringFrequency = 'weekly' | 'monthly' | 'yearly';

interface UserRecord {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  createdAt: string;
}

interface UserPreferences {
  userId: string;
  currency: CurrencyCode;
  theme: ThemeMode;
  monthlyBudget: number;
  categoryLimits: Record<string, number>;
  customCategories: string[];
}

interface IncomeRecord {
  id: string;
  userId: string;
  amount: number;
  source: string;
  description: string;
  date: string;
  createdAt: string;
}

interface ExpenseRecord {
  id: string;
  userId: string;
  amount: number;
  category: string;
  paymentMethod: string;
  note: string;
  date: string;
  recurringId?: string;
  createdAt: string;
}

interface RecurringRule {
  id: string;
  userId: string;
  title: string;
  amount: number;
  category: string;
  paymentMethod: string;
  frequency: RecurringFrequency;
  nextDueDate: string;
  active: boolean;
  lastLoggedMonth?: string;
  createdAt: string;
}

interface SavingsGoal {
  id: string;
  userId: string;
  title: string;
  targetAmount: number;
  savedAmount: number;
  deadline: string;
  createdAt: string;
}

interface DatabaseSchema {
  users: UserRecord[];
  preferences: UserPreferences[];
  incomes: IncomeRecord[];
  expenses: ExpenseRecord[];
  recurringRules: RecurringRule[];
  savingsGoals: SavingsGoal[];
}

interface AuthenticatedRequest extends Request {
  userId?: string;
}

const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'ledger-db.json');
const SECRET_PATH = path.join(DATA_DIR, 'session.key');
const COOKIE_NAME = 'ledger_session';
const TOKEN_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days

function ensureDataDir(): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function getSessionSecret(): string {
  if (process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 16) {
    return process.env.SESSION_SECRET;
  }
  ensureDataDir();
  if (fs.existsSync(SECRET_PATH)) {
    return fs.readFileSync(SECRET_PATH, 'utf8').trim();
  }
  const generated = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(SECRET_PATH, generated, 'utf8');
  return generated;
}

const SESSION_SECRET = getSessionSecret();

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const derived = crypto.scryptSync(password, salt, 64);
  const keyBuf = Buffer.from(keyHex, 'hex');
  if (derived.length !== keyBuf.length) return false;
  return crypto.timingSafeEqual(derived, keyBuf);
}

function createSessionToken(userId: string): string {
  const payloadObj = { uid: userId, exp: Date.now() + TOKEN_TTL_MS };
  const payload = Buffer.from(JSON.stringify(payloadObj), 'utf8').toString('base64url');
  const signature = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(payload)
    .digest('base64url');
  return `${payload}.${signature}`;
}

function verifySessionToken(token: string): string | null {
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [payload, signature] = parts;
  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(payload)
    .digest('base64url');
  const sigBuf = Buffer.from(signature, 'utf8');
  const expBuf = Buffer.from(expectedSig, 'utf8');
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }
  try {
    const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as {
      uid?: string;
      exp?: number;
    };
    if (!parsed.uid || !parsed.exp || Date.now() > parsed.exp) {
      return null;
    }
    return parsed.uid;
  } catch {
    return null;
  }
}

function parseCookies(cookieHeader: string | undefined): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;
  for (const part of cookieHeader.split(';')) {
    const eqIndex = part.indexOf('=');
    if (eqIndex > 0) {
      const key = part.slice(0, eqIndex).trim();
      const val = decodeURIComponent(part.slice(eqIndex + 1).trim());
      result[key] = val;
    }
  }
  return result;
}

function createSeedDatabase(): DatabaseSchema {
  const demoUserId = 'usr_demo_jitendra';
  const now = '2026-11-01T09:00:00.000Z';

  return {
    users: [
      {
        id: demoUserId,
        name: 'Jitendra Satheeshkumar',
        email: 'jitendra@simats.edu',
        passwordHash: hashPassword('demo1234'),
        createdAt: '2026-09-01T08:00:00.000Z',
      },
    ],
    preferences: [
      {
        userId: demoUserId,
        currency: 'INR',
        theme: 'light',
        monthlyBudget: 40000,
        categoryLimits: {
          Bills: 50000,
          Food: 10000,
          Shopping: 8000,
          Transport: 4000,
          Rent: 6000,
          Healthcare: 4000,
          Education: 5000,
          Entertainment: 3000,
        },
        customCategories: ['Subscriptions'],
      },
    ],
    incomes: [
      {
        id: 'inc_sep_1',
        userId: demoUserId,
        amount: 48000,
        source: 'Salary',
        description: 'Monthly stipend and engineering internship',
        date: '2026-09-02',
        createdAt: '2026-09-02T10:00:00.000Z',
      },
      {
        id: 'inc_sep_2',
        userId: demoUserId,
        amount: 4500,
        source: 'Part-time',
        description: 'Weekend C programming lab mentoring',
        date: '2026-09-19',
        createdAt: '2026-09-19T16:30:00.000Z',
      },
      {
        id: 'inc_oct_1',
        userId: demoUserId,
        amount: 50000,
        source: 'Salary',
        description: 'Monthly salary credit',
        date: '2026-10-02',
        createdAt: '2026-10-02T09:30:00.000Z',
      },
      {
        id: 'inc_oct_2',
        userId: demoUserId,
        amount: 3000,
        source: 'Gifts',
        description: 'Festival family gift',
        date: '2026-10-24',
        createdAt: '2026-10-24T12:15:00.000Z',
      },
      {
        id: 'inc_nov_1',
        userId: demoUserId,
        amount: 52000,
        source: 'Salary',
        description: 'Monthly salary credit',
        date: '2026-11-02',
        createdAt: now,
      },
      {
        id: 'inc_nov_2',
        userId: demoUserId,
        amount: 6500,
        source: 'Part-time',
        description: 'Freelance web dashboard prototype',
        date: '2026-11-11',
        createdAt: '2026-11-11T14:20:00.000Z',
      },
    ],
    expenses: [
      // September 2026
      {
        id: 'exp_sep_1',
        userId: demoUserId,
        amount: 5000,
        category: 'Rent',
        paymentMethod: 'Net Banking',
        note: 'Hostel room rent',
        date: '2026-09-05',
        createdAt: '2026-09-05T10:00:00.000Z',
      },
      {
        id: 'exp_sep_2',
        userId: demoUserId,
        amount: 2400,
        category: 'Food',
        paymentMethod: 'UPI',
        note: 'Mess & weekly groceries',
        date: '2026-09-12',
        createdAt: '2026-09-12T19:00:00.000Z',
      },
      {
        id: 'exp_sep_3',
        userId: demoUserId,
        amount: 1650,
        category: 'Transport',
        paymentMethod: 'UPI',
        note: 'Metro pass & cab rides',
        date: '2026-09-16',
        createdAt: '2026-09-16T08:40:00.000Z',
      },
      {
        id: 'exp_sep_4',
        userId: demoUserId,
        amount: 820,
        category: 'Bills',
        paymentMethod: 'UPI',
        note: 'Mobile & broadband bill',
        date: '2026-09-20',
        createdAt: '2026-09-20T11:10:00.000Z',
      },
      {
        id: 'exp_sep_5',
        userId: demoUserId,
        amount: 1200,
        category: 'Shopping',
        paymentMethod: 'Debit Card',
        note: 'Campus supplies',
        date: '2026-09-26',
        createdAt: '2026-09-26T17:05:00.000Z',
      },
      // October 2026
      {
        id: 'exp_oct_1',
        userId: demoUserId,
        amount: 5000,
        category: 'Rent',
        paymentMethod: 'Net Banking',
        note: 'Hostel room rent',
        date: '2026-10-05',
        createdAt: '2026-10-05T10:00:00.000Z',
      },
      {
        id: 'exp_oct_2',
        userId: demoUserId,
        amount: 2750,
        category: 'Food',
        paymentMethod: 'UPI',
        note: 'Groceries & coffee',
        date: '2026-10-14',
        createdAt: '2026-10-14T20:15:00.000Z',
      },
      {
        id: 'exp_oct_3',
        userId: demoUserId,
        amount: 2200,
        category: 'Education',
        paymentMethod: 'Debit Card',
        note: 'Reference textbooks & exam fee',
        date: '2026-10-18',
        createdAt: '2026-10-18T14:00:00.000Z',
      },
      {
        id: 'exp_oct_4',
        userId: demoUserId,
        amount: 890,
        category: 'Bills',
        paymentMethod: 'UPI',
        note: 'Electricity & broadband',
        date: '2026-10-21',
        createdAt: '2026-10-21T11:20:00.000Z',
      },
      {
        id: 'exp_oct_5',
        userId: demoUserId,
        amount: 1800,
        category: 'Shopping',
        paymentMethod: 'Credit Card',
        note: 'Festive apparel',
        date: '2026-10-27',
        createdAt: '2026-10-27T18:30:00.000Z',
      },
      // November 2026 (matches presentation Slide 11 totals: ₹12,350.21)
      {
        id: 'exp_nov_1',
        userId: demoUserId,
        amount: 1500.21,
        category: 'Healthcare',
        paymentMethod: 'Debit Card',
        note: 'Dental checkup & pharmacy',
        date: '2026-11-13',
        createdAt: '2026-11-13T15:30:00.000Z',
      },
      {
        id: 'exp_nov_2',
        userId: demoUserId,
        amount: 2000,
        category: 'Shopping',
        paymentMethod: 'Credit Card',
        note: 'Desk lamp & accessories',
        date: '2026-11-17',
        createdAt: '2026-11-17T18:10:00.000Z',
      },
      {
        id: 'exp_nov_3',
        userId: demoUserId,
        amount: 3000,
        category: 'Food',
        paymentMethod: 'UPI',
        note: 'Monthly meal plan & groceries',
        date: '2026-11-18',
        createdAt: '2026-11-18T12:45:00.000Z',
      },
      {
        id: 'exp_nov_4',
        userId: demoUserId,
        amount: 5000,
        category: 'Rent',
        paymentMethod: 'Net Banking',
        note: 'Monthly accommodation rent',
        date: '2026-11-18',
        createdAt: '2026-11-18T09:05:00.000Z',
      },
      {
        id: 'exp_nov_5',
        userId: demoUserId,
        amount: 850,
        category: 'Bills',
        paymentMethod: 'UPI',
        note: 'Internet & mobile utility',
        date: '2026-11-18',
        createdAt: '2026-11-18T11:30:00.000Z',
      },
    ],
    recurringRules: [
      {
        id: 'rec_1',
        userId: demoUserId,
        title: 'Monthly Accommodation Rent',
        amount: 5000,
        category: 'Rent',
        paymentMethod: 'Net Banking',
        frequency: 'monthly',
        nextDueDate: '2026-12-05',
        active: true,
        lastLoggedMonth: '2026-11',
        createdAt: '2026-09-01T09:00:00.000Z',
      },
      {
        id: 'rec_2',
        userId: demoUserId,
        title: 'Broadband & Mobile Recharge',
        amount: 850,
        category: 'Bills',
        paymentMethod: 'UPI',
        frequency: 'monthly',
        nextDueDate: '2026-12-18',
        active: true,
        lastLoggedMonth: '2026-11',
        createdAt: '2026-09-01T09:00:00.000Z',
      },
      {
        id: 'rec_3',
        userId: demoUserId,
        title: 'Developer Cloud & Learning Pass',
        amount: 499,
        category: 'Subscriptions',
        paymentMethod: 'Debit Card',
        frequency: 'monthly',
        nextDueDate: '2026-11-25',
        active: true,
        createdAt: '2026-10-01T09:00:00.000Z',
      },
    ],
    savingsGoals: [
      {
        id: 'goal_1',
        userId: demoUserId,
        title: 'Emergency Reserve Fund',
        targetAmount: 100000,
        savedAmount: 64000,
        deadline: '2027-06-30',
        createdAt: '2026-09-01T09:00:00.000Z',
      },
      {
        id: 'goal_2',
        userId: demoUserId,
        title: 'Workstation Laptop Upgrade',
        targetAmount: 75000,
        savedAmount: 28500,
        deadline: '2027-03-15',
        createdAt: '2026-10-05T09:00:00.000Z',
      },
    ],
  };
}

function readDb(): DatabaseSchema {
  ensureDataDir();
  if (!fs.existsSync(DB_PATH)) {
    const seeded = createSeedDatabase();
    writeDb(seeded);
    return seeded;
  }
  const raw = fs.readFileSync(DB_PATH, 'utf8');
  return JSON.parse(raw) as DatabaseSchema;
}

function writeDb(data: DatabaseSchema): void {
  ensureDataDir();
  const tmpPath = `${DB_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmpPath, DB_PATH);
}

function defaultPreferencesForUser(userId: string): UserPreferences {
  return {
    userId,
    currency: 'INR',
    theme: 'light',
    monthlyBudget: 25000,
    categoryLimits: {
      Food: 6000,
      Transport: 3000,
      Bills: 4000,
      Shopping: 4000,
    },
    customCategories: [],
  };
}

function advanceDateByFrequency(dateStr: string, frequency: RecurringFrequency): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y || 2026, (m || 1) - 1, d || 1));
  if (frequency === 'weekly') {
    dt.setUTCDate(dt.getUTCDate() + 7);
  } else if (frequency === 'yearly') {
    dt.setUTCFullYear(dt.getUTCFullYear() + 1);
  } else {
    dt.setUTCMonth(dt.getUTCMonth() + 1);
  }
  return dt.toISOString().slice(0, 10);
}

function setSessionCookie(res: Response, token: string): void {
  res.setHeader(
    'Set-Cookie',
    `${COOKIE_NAME}=${encodeURIComponent(token)}; HttpOnly; Path=/; Max-Age=${Math.floor(
      TOKEN_TTL_MS / 1000
    )}; SameSite=Lax`
  );
}

function clearSessionCookie(res: Response): void {
  res.setHeader(
    'Set-Cookie',
    `${COOKIE_NAME}=; HttpOnly; Path=/; Max-Age=0; SameSite=Lax`
  );
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const authHeader = req.headers.authorization;
  let token: string | null = null;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7).trim();
  }
  if (!token) {
    const cookies = parseCookies(req.headers.cookie);
    token = cookies[COOKIE_NAME] || null;
  }
  if (!token) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }
  const userId = verifySessionToken(token);
  if (!userId) {
    res.status(401).json({ error: 'Invalid or expired session' });
    return;
  }
  req.userId = userId;
  next();
}

function sanitizeUser(user: UserRecord) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    createdAt: user.createdAt,
  };
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // Ensure DB exists on boot
  readDb();

  // --- Module 1: Authentication & Profile Management ---
  app.post('/api/auth/register', (req: Request, res: Response) => {
    const { name, email, password } = req.body as {
      name?: string;
      email?: string;
      password?: string;
    };
    const cleanName = (name || '').trim();
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanPassword = password || '';

    if (cleanName.length < 2) {
      res.status(400).json({ error: 'Please enter your full name (at least 2 characters).' });
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      res.status(400).json({ error: 'Please enter a valid email address.' });
      return;
    }
    if (cleanPassword.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters.' });
      return;
    }

    const db = readDb();
    if (db.users.some((u) => u.email.toLowerCase() === cleanEmail)) {
      res.status(409).json({ error: 'An account with this email already exists.' });
      return;
    }

    const userId = `usr_${crypto.randomUUID().slice(0, 12)}`;
    const newUser: UserRecord = {
      id: userId,
      name: cleanName,
      email: cleanEmail,
      passwordHash: hashPassword(cleanPassword),
      createdAt: new Date().toISOString(),
    };
    const newPrefs = defaultPreferencesForUser(userId);

    db.users.push(newUser);
    db.preferences.push(newPrefs);
    writeDb(db);

    const token = createSessionToken(userId);
    setSessionCookie(res, token);
    res.status(201).json({
      token,
      user: sanitizeUser(newUser),
      preferences: newPrefs,
    });
  });

  app.post('/api/auth/login', (req: Request, res: Response) => {
    const { email, password } = req.body as { email?: string; password?: string };
    const cleanEmail = (email || '').trim().toLowerCase();
    const cleanPassword = password || '';

    if (!cleanEmail || !cleanPassword) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const db = readDb();
    const user = db.users.find((u) => u.email.toLowerCase() === cleanEmail);
    if (!user || !verifyPassword(cleanPassword, user.passwordHash)) {
      res.status(401).json({ error: 'Invalid email or password.' });
      return;
    }

    let prefs = db.preferences.find((p) => p.userId === user.id);
    if (!prefs) {
      prefs = defaultPreferencesForUser(user.id);
      db.preferences.push(prefs);
      writeDb(db);
    }

    const token = createSessionToken(user.id);
    setSessionCookie(res, token);
    res.json({
      token,
      user: sanitizeUser(user),
      preferences: prefs,
    });
  });

  app.post('/api/auth/logout', (_req: Request, res: Response) => {
    clearSessionCookie(res);
    res.json({ ok: true });
  });

  app.get('/api/auth/me', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    const user = db.users.find((u) => u.id === req.userId);
    if (!user) {
      res.status(404).json({ error: 'Account not found.' });
      return;
    }
    const prefs =
      db.preferences.find((p) => p.userId === user.id) || defaultPreferencesForUser(user.id);
    res.json({ user: sanitizeUser(user), preferences: prefs });
  });

  app.put('/api/auth/profile', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { name, email, currentPassword, newPassword } = req.body as {
      name?: string;
      email?: string;
      currentPassword?: string;
      newPassword?: string;
    };

    const db = readDb();
    const user = db.users.find((u) => u.id === req.userId);
    if (!user) {
      res.status(404).json({ error: 'Account not found.' });
      return;
    }

    if (name !== undefined) {
      const cleanName = name.trim();
      if (cleanName.length < 2) {
        res.status(400).json({ error: 'Display name must be at least 2 characters.' });
        return;
      }
      user.name = cleanName;
    }

    if (email !== undefined) {
      const cleanEmail = email.trim().toLowerCase();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
        res.status(400).json({ error: 'Please provide a valid email address.' });
        return;
      }
      const duplicate = db.users.find(
        (u) => u.id !== user.id && u.email.toLowerCase() === cleanEmail
      );
      if (duplicate) {
        res.status(409).json({ error: 'That email address is already in use.' });
        return;
      }
      user.email = cleanEmail;
    }

    if (newPassword) {
      if (!currentPassword || !verifyPassword(currentPassword, user.passwordHash)) {
        res.status(400).json({ error: 'Current password is incorrect.' });
        return;
      }
      if (newPassword.length < 6) {
        res.status(400).json({ error: 'New password must be at least 6 characters.' });
        return;
      }
      user.passwordHash = hashPassword(newPassword);
    }

    writeDb(db);
    res.json({ user: sanitizeUser(user) });
  });

  // --- Hydrated Workspace Snapshot (Strict User Isolation) ---
  app.get('/api/workspace', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    const user = db.users.find((u) => u.id === req.userId);
    if (!user) {
      res.status(404).json({ error: 'Account not found.' });
      return;
    }
    const preferences =
      db.preferences.find((p) => p.userId === user.id) || defaultPreferencesForUser(user.id);

    res.json({
      user: sanitizeUser(user),
      preferences,
      incomes: db.incomes
        .filter((item) => item.userId === user.id)
        .sort((a, b) => b.date.localeCompare(a.date)),
      expenses: db.expenses
        .filter((item) => item.userId === user.id)
        .sort((a, b) => b.date.localeCompare(a.date)),
      recurringRules: db.recurringRules.filter((item) => item.userId === user.id),
      savingsGoals: db.savingsGoals.filter((item) => item.userId === user.id),
    });
  });

  // --- Module 2: Income Management ---
  app.post('/api/incomes', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { amount, source, description, date } = req.body as {
      amount?: number;
      source?: string;
      description?: string;
      date?: string;
    };
    const numericAmount = Number(amount);
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      res.status(400).json({ error: 'Income amount must be greater than zero.' });
      return;
    }
    if (!source || !source.trim()) {
      res.status(400).json({ error: 'Income source is required.' });
      return;
    }
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      res.status(400).json({ error: 'Valid date (YYYY-MM-DD) is required.' });
      return;
    }

    const db = readDb();
    const record: IncomeRecord = {
      id: `inc_${crypto.randomUUID().slice(0, 10)}`,
      userId: req.userId!,
      amount: Math.round(numericAmount * 100) / 100,
      source: source.trim(),
      description: (description || '').trim(),
      date,
      createdAt: new Date().toISOString(),
    };
    db.incomes.push(record);
    writeDb(db);
    res.status(201).json({ income: record });
  });

  app.put('/api/incomes/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    const record = db.incomes.find(
      (item) => item.id === req.params.id && item.userId === req.userId
    );
    if (!record) {
      res.status(404).json({ error: 'Income record not found.' });
      return;
    }

    const { amount, source, description, date } = req.body as {
      amount?: number;
      source?: string;
      description?: string;
      date?: string;
    };
    if (amount !== undefined) {
      const numericAmount = Number(amount);
      if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
        res.status(400).json({ error: 'Income amount must be greater than zero.' });
        return;
      }
      record.amount = Math.round(numericAmount * 100) / 100;
    }
    if (source !== undefined && source.trim()) {
      record.source = source.trim();
    }
    if (description !== undefined) {
      record.description = description.trim();
    }
    if (date !== undefined && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
      record.date = date;
    }

    writeDb(db);
    res.json({ income: record });
  });

  app.delete('/api/incomes/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    const idx = db.incomes.findIndex(
      (item) => item.id === req.params.id && item.userId === req.userId
    );
    if (idx === -1) {
      res.status(404).json({ error: 'Income record not found.' });
      return;
    }
    db.incomes.splice(idx, 1);
    writeDb(db);
    res.json({ ok: true });
  });

  // --- Module 3: Expense Management ---
  app.post('/api/expenses', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { amount, category, paymentMethod, note, date } = req.body as {
      amount?: number;
      category?: string;
      paymentMethod?: string;
      note?: string;
      date?: string;
    };
    const numericAmount = Number(amount);
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      res.status(400).json({ error: 'Expense amount must be greater than zero.' });
      return;
    }
    if (!category || !category.trim()) {
      res.status(400).json({ error: 'Expense category is required.' });
      return;
    }
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      res.status(400).json({ error: 'Valid date (YYYY-MM-DD) is required.' });
      return;
    }

    const db = readDb();
    const record: ExpenseRecord = {
      id: `exp_${crypto.randomUUID().slice(0, 10)}`,
      userId: req.userId!,
      amount: Math.round(numericAmount * 100) / 100,
      category: category.trim(),
      paymentMethod: (paymentMethod || 'UPI').trim(),
      note: (note || '').trim(),
      date,
      createdAt: new Date().toISOString(),
    };
    db.expenses.push(record);
    writeDb(db);
    res.status(201).json({ expense: record });
  });

  app.put('/api/expenses/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    const record = db.expenses.find(
      (item) => item.id === req.params.id && item.userId === req.userId
    );
    if (!record) {
      res.status(404).json({ error: 'Expense record not found.' });
      return;
    }

    const { amount, category, paymentMethod, note, date } = req.body as {
      amount?: number;
      category?: string;
      paymentMethod?: string;
      note?: string;
      date?: string;
    };
    if (amount !== undefined) {
      const numericAmount = Number(amount);
      if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
        res.status(400).json({ error: 'Expense amount must be greater than zero.' });
        return;
      }
      record.amount = Math.round(numericAmount * 100) / 100;
    }
    if (category !== undefined && category.trim()) {
      record.category = category.trim();
    }
    if (paymentMethod !== undefined && paymentMethod.trim()) {
      record.paymentMethod = paymentMethod.trim();
    }
    if (note !== undefined) {
      record.note = note.trim();
    }
    if (date !== undefined && /^\d{4}-\d{2}-\d{2}$/.test(date)) {
      record.date = date;
    }

    writeDb(db);
    res.json({ expense: record });
  });

  app.delete('/api/expenses/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    const idx = db.expenses.findIndex(
      (item) => item.id === req.params.id && item.userId === req.userId
    );
    if (idx === -1) {
      res.status(404).json({ error: 'Expense record not found.' });
      return;
    }
    db.expenses.splice(idx, 1);
    writeDb(db);
    res.json({ ok: true });
  });

  // --- Module 4 & 6: Budgets & Personalisation Preferences ---
  app.put('/api/preferences', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    let prefs = db.preferences.find((p) => p.userId === req.userId);
    if (!prefs) {
      prefs = defaultPreferencesForUser(req.userId!);
      db.preferences.push(prefs);
    }

    const { currency, theme, monthlyBudget, categoryLimits, customCategories } = req.body as {
      currency?: CurrencyCode;
      theme?: ThemeMode;
      monthlyBudget?: number;
      categoryLimits?: Record<string, number>;
      customCategories?: string[];
    };

    if (currency && ['INR', 'USD', 'EUR', 'GBP'].includes(currency)) {
      prefs.currency = currency;
    }
    if (theme && ['light', 'dark'].includes(theme)) {
      prefs.theme = theme;
    }
    if (monthlyBudget !== undefined) {
      const num = Number(monthlyBudget);
      if (!Number.isFinite(num) || num < 0) {
        res.status(400).json({ error: 'Monthly budget must be zero or greater.' });
        return;
      }
      prefs.monthlyBudget = Math.round(num * 100) / 100;
    }
    if (categoryLimits && typeof categoryLimits === 'object') {
      const sanitizedLimits: Record<string, number> = {};
      for (const [cat, limit] of Object.entries(categoryLimits)) {
        const num = Number(limit);
        if (Number.isFinite(num) && num > 0) {
          sanitizedLimits[cat.trim()] = Math.round(num * 100) / 100;
        }
      }
      prefs.categoryLimits = sanitizedLimits;
    }
    if (Array.isArray(customCategories)) {
      prefs.customCategories = Array.from(
        new Set(
          customCategories
            .map((c) => String(c).trim())
            .filter((c) => c.length > 0 && c.length <= 32)
        )
      );
    }

    writeDb(db);
    res.json({ preferences: prefs });
  });

  // --- Future Scope: Recurring Expenses & Bills ---
  app.post('/api/recurring', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { title, amount, category, paymentMethod, frequency, nextDueDate } = req.body as {
      title?: string;
      amount?: number;
      category?: string;
      paymentMethod?: string;
      frequency?: RecurringFrequency;
      nextDueDate?: string;
    };
    const numericAmount = Number(amount);
    if (!title || !title.trim()) {
      res.status(400).json({ error: 'Recurring bill title is required.' });
      return;
    }
    if (!Number.isFinite(numericAmount) || numericAmount <= 0) {
      res.status(400).json({ error: 'Amount must be greater than zero.' });
      return;
    }
    if (!category || !category.trim()) {
      res.status(400).json({ error: 'Category is required.' });
      return;
    }
    if (!nextDueDate || !/^\d{4}-\d{2}-\d{2}$/.test(nextDueDate)) {
      res.status(400).json({ error: 'Valid next due date is required.' });
      return;
    }

    const db = readDb();
    const rule: RecurringRule = {
      id: `rec_${crypto.randomUUID().slice(0, 10)}`,
      userId: req.userId!,
      title: title.trim(),
      amount: Math.round(numericAmount * 100) / 100,
      category: category.trim(),
      paymentMethod: (paymentMethod || 'UPI').trim(),
      frequency:
        frequency && ['weekly', 'monthly', 'yearly'].includes(frequency) ? frequency : 'monthly',
      nextDueDate,
      active: true,
      createdAt: new Date().toISOString(),
    };
    db.recurringRules.push(rule);
    writeDb(db);
    res.status(201).json({ recurringRule: rule });
  });

  app.put('/api/recurring/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    const rule = db.recurringRules.find(
      (item) => item.id === req.params.id && item.userId === req.userId
    );
    if (!rule) {
      res.status(404).json({ error: 'Recurring rule not found.' });
      return;
    }
    const { active, amount, title, nextDueDate } = req.body as {
      active?: boolean;
      amount?: number;
      title?: string;
      nextDueDate?: string;
    };
    if (active !== undefined) rule.active = Boolean(active);
    if (title !== undefined && title.trim()) rule.title = title.trim();
    if (amount !== undefined && Number(amount) > 0) {
      rule.amount = Math.round(Number(amount) * 100) / 100;
    }
    if (nextDueDate && /^\d{4}-\d{2}-\d{2}$/.test(nextDueDate)) {
      rule.nextDueDate = nextDueDate;
    }
    writeDb(db);
    res.json({ recurringRule: rule });
  });

  app.post('/api/recurring/:id/log', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    const rule = db.recurringRules.find(
      (item) => item.id === req.params.id && item.userId === req.userId
    );
    if (!rule) {
      res.status(404).json({ error: 'Recurring rule not found.' });
      return;
    }

    const { date } = req.body as { date?: string };
    const logDate =
      date && /^\d{4}-\d{2}-\d{2}$/.test(date) ? date : new Date().toISOString().slice(0, 10);

    const newExpense: ExpenseRecord = {
      id: `exp_${crypto.randomUUID().slice(0, 10)}`,
      userId: req.userId!,
      amount: rule.amount,
      category: rule.category,
      paymentMethod: rule.paymentMethod,
      note: `${rule.title} (Recurring)`,
      date: logDate,
      recurringId: rule.id,
      createdAt: new Date().toISOString(),
    };
    db.expenses.push(newExpense);
    rule.lastLoggedMonth = logDate.slice(0, 7);
    rule.nextDueDate = advanceDateByFrequency(rule.nextDueDate, rule.frequency);
    writeDb(db);

    res.status(201).json({ expense: newExpense, recurringRule: rule });
  });

  app.delete('/api/recurring/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    const idx = db.recurringRules.findIndex(
      (item) => item.id === req.params.id && item.userId === req.userId
    );
    if (idx === -1) {
      res.status(404).json({ error: 'Recurring rule not found.' });
      return;
    }
    db.recurringRules.splice(idx, 1);
    writeDb(db);
    res.json({ ok: true });
  });

  // --- Future Scope: Savings Goals Tracker ---
  app.post('/api/goals', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const { title, targetAmount, savedAmount, deadline } = req.body as {
      title?: string;
      targetAmount?: number;
      savedAmount?: number;
      deadline?: string;
    };
    const target = Number(targetAmount);
    const saved = Number(savedAmount || 0);
    if (!title || !title.trim()) {
      res.status(400).json({ error: 'Goal title is required.' });
      return;
    }
    if (!Number.isFinite(target) || target <= 0) {
      res.status(400).json({ error: 'Target amount must be greater than zero.' });
      return;
    }
    if (!Number.isFinite(saved) || saved < 0) {
      res.status(400).json({ error: 'Initial saved amount cannot be negative.' });
      return;
    }

    const db = readDb();
    const goal: SavingsGoal = {
      id: `goal_${crypto.randomUUID().slice(0, 10)}`,
      userId: req.userId!,
      title: title.trim(),
      targetAmount: Math.round(target * 100) / 100,
      savedAmount: Math.round(saved * 100) / 100,
      deadline: deadline && /^\d{4}-\d{2}-\d{2}$/.test(deadline) ? deadline : '2027-12-31',
      createdAt: new Date().toISOString(),
    };
    db.savingsGoals.push(goal);
    writeDb(db);
    res.status(201).json({ goal });
  });

  app.post('/api/goals/:id/contribute', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    const goal = db.savingsGoals.find(
      (item) => item.id === req.params.id && item.userId === req.userId
    );
    if (!goal) {
      res.status(404).json({ error: 'Savings goal not found.' });
      return;
    }
    const { delta } = req.body as { delta?: number };
    const change = Number(delta);
    if (!Number.isFinite(change) || change === 0) {
      res.status(400).json({ error: 'Please provide a non-zero contribution amount.' });
      return;
    }
    goal.savedAmount = Math.max(0, Math.round((goal.savedAmount + change) * 100) / 100);
    writeDb(db);
    res.json({ goal });
  });

  app.delete('/api/goals/:id', requireAuth, (req: AuthenticatedRequest, res: Response) => {
    const db = readDb();
    const idx = db.savingsGoals.findIndex(
      (item) => item.id === req.params.id && item.userId === req.userId
    );
    if (idx === -1) {
      res.status(404).json({ error: 'Savings goal not found.' });
      return;
    }
    db.savingsGoals.splice(idx, 1);
    writeDb(db);
    res.json({ ok: true });
  });

  // --- Vite / Production Static Handling ---
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const port = Number(process.env.PORT) || 3000;
  app.listen(port, '0.0.0.0', () => {
    console.log(`LedgerFlow server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
