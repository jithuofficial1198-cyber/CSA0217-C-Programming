import type {
  BudgetHealthStatus,
  CategoryBudgetProgress,
  CategorySpikeInsight,
  CurrencyCode,
  ExpenseRecord,
  IncomeRecord,
  SpendingPrediction,
} from '../types/finance';

export const DEFAULT_EXPENSE_CATEGORIES = [
  'Food',
  'Transport',
  'Education',
  'Shopping',
  'Entertainment',
  'Healthcare',
  'Bills',
  'Rent',
];

export const INCOME_SOURCES = ['Salary', 'Allowance', 'Part-time', 'Gifts', 'Other'];

export const PAYMENT_METHODS = ['UPI', 'Debit Card', 'Credit Card', 'Cash', 'Net Banking'];

export const CURRENCY_CONFIG: Record<
  CurrencyCode,
  { symbol: string; locale: string; label: string }
> = {
  INR: { symbol: '₹', locale: 'en-IN', label: 'INR (₹)' },
  USD: { symbol: '$', locale: 'en-US', label: 'USD ($)' },
  EUR: { symbol: '€', locale: 'de-DE', label: 'EUR (€)' },
  GBP: { symbol: '£', locale: 'en-GB', label: 'GBP (£)' },
};

export const CATEGORY_CHART_COLORS = [
  '#2563EB', // Blue
  '#0D9488', // Teal
  '#F59E0B', // Amber
  '#EC4899', // Rose
  '#6366F1', // Indigo
  '#10B981', // Emerald
  '#F97316', // Orange
  '#8B5CF6', // Violet
  '#64748B', // Slate
];

export function formatCurrency(amount: number, currency: CurrencyCode): string {
  const cfg = CURRENCY_CONFIG[currency] || CURRENCY_CONFIG.INR;
  const absVal = Math.abs(amount);
  const formatted = new Intl.NumberFormat(cfg.locale, {
    minimumFractionDigits: absVal % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(absVal);
  return `${amount < 0 ? '-' : ''}${cfg.symbol}${formatted}`;
}

export function formatCurrencyExact(amount: number, currency: CurrencyCode): string {
  const cfg = CURRENCY_CONFIG[currency] || CURRENCY_CONFIG.INR;
  const absVal = Math.abs(amount);
  const formatted = new Intl.NumberFormat(cfg.locale, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(absVal);
  return `${amount < 0 ? '-' : ''}${cfg.symbol}${formatted}`;
}

export function getMonthLabel(monthKey: string): string {
  const [yearStr, monthStr] = monthKey.split('-');
  const year = Number(yearStr);
  const month = Number(monthStr);
  if (!year || !month) return monthKey;
  const date = new Date(Date.UTC(year, month - 1, 1));
  return new Intl.DateTimeFormat('en-US', {
    month: 'long',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(date);
}

export function getShortMonthLabel(monthKey: string): string {
  const [yearStr, monthStr] = monthKey.split('-');
  const year = Number(yearStr);
  const month = Number(monthStr);
  if (!year || !month) return monthKey;
  const date = new Date(Date.UTC(year, month - 1, 1));
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    year: '2-digit',
    timeZone: 'UTC',
  }).format(date);
}

export function calculateIncome(incomes: IncomeRecord[], periodPrefix?: string): number {
  let total = 0;
  for (let i = 0; i < incomes.length; i++) {
    if (!periodPrefix || incomes[i].date.startsWith(periodPrefix)) {
      total += incomes[i].amount;
    }
  }
  return Math.round(total * 100) / 100;
}

export function calculateExpense(expenses: ExpenseRecord[], periodPrefix?: string): number {
  let total = 0;
  for (let i = 0; i < expenses.length; i++) {
    if (!periodPrefix || expenses[i].date.startsWith(periodPrefix)) {
      total += expenses[i].amount;
    }
  }
  return Math.round(total * 100) / 100;
}

export function calculateBalance(totalIncome: number, totalExpense: number): number {
  return Math.round((totalIncome - totalExpense) * 100) / 100;
}

export function evaluateBudgetStatus(spent: number, limit: number | null): {
  percentage: number;
  remaining: number;
  status: BudgetHealthStatus;
} {
  if (!limit || limit <= 0) {
    return { percentage: 0, remaining: 0, status: 'unconfigured' };
  }
  const percentage = Math.round(((spent / limit) * 100) * 10) / 10;
  const remaining = Math.round((limit - spent) * 100) / 100;
  let status: BudgetHealthStatus = 'healthy';
  if (percentage > 100) {
    status = 'exceeded';
  } else if (percentage >= 80) {
    status = 'warning';
  }
  return { percentage, remaining, status };
}

export function groupExpensesByCategory(
  expenses: ExpenseRecord[],
  monthKey?: string
): Array<{ category: string; amount: number; color: string }> {
  const map = new Map<string, number>();
  for (const exp of expenses) {
    if (!monthKey || exp.date.startsWith(monthKey)) {
      map.set(exp.category, (map.get(exp.category) || 0) + exp.amount);
    }
  }
  const entries = Array.from(map.entries())
    .map(([category, amount]) => ({
      category,
      amount: Math.round(amount * 100) / 100,
    }))
    .sort((a, b) => b.amount - a.amount);

  return entries.map((entry, idx) => ({
    ...entry,
    color: CATEGORY_CHART_COLORS[idx % CATEGORY_CHART_COLORS.length],
  }));
}

export function computeCategoryBudgets(
  expenses: ExpenseRecord[],
  categoryLimits: Record<string, number>,
  monthKey: string
): CategoryBudgetProgress[] {
  const spentMap = new Map<string, number>();
  for (const exp of expenses) {
    if (exp.date.startsWith(monthKey)) {
      spentMap.set(exp.category, (spentMap.get(exp.category) || 0) + exp.amount);
    }
  }

  const allCategories = new Set<string>([
    ...Object.keys(categoryLimits),
    ...Array.from(spentMap.keys()),
  ]);

  const rows: CategoryBudgetProgress[] = [];
  for (const category of allCategories) {
    const spent = Math.round((spentMap.get(category) || 0) * 100) / 100;
    const limit = categoryLimits[category] > 0 ? categoryLimits[category] : null;
    if (spent === 0 && !limit) continue;
    const evaluation = evaluateBudgetStatus(spent, limit);
    rows.push({
      category,
      spent,
      limit,
      percentage: evaluation.percentage,
      status: evaluation.status,
    });
  }

  return rows.sort((a, b) => {
    if (a.status === 'exceeded' && b.status !== 'exceeded') return -1;
    if (b.status === 'exceeded' && a.status !== 'exceeded') return 1;
    return b.spent - a.spent;
  });
}

export function getPreviousMonthKey(monthKey: string): string {
  const [y, m] = monthKey.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 2, 1));
  return `${dt.getUTCFullYear()}-${String(dt.getUTCMonth() + 1).padStart(2, '0')}`;
}

export function computeInsightsAndForecast(
  incomes: IncomeRecord[],
  expenses: ExpenseRecord[],
  activeMonth: string
): SpendingPrediction {
  const currentMonthExpenses = expenses.filter((e) => e.date.startsWith(activeMonth));
  const currentTotal = calculateExpense(currentMonthExpenses);
  const currentIncome = calculateIncome(incomes, activeMonth);

  const prevMonthKey = getPreviousMonthKey(activeMonth);
  const prevMonthExpenses = expenses.filter((e) => e.date.startsWith(prevMonthKey));

  // Category month-over-month spike analysis
  const curByCat = new Map<string, number>();
  for (const e of currentMonthExpenses) {
    curByCat.set(e.category, (curByCat.get(e.category) || 0) + e.amount);
  }
  const prevByCat = new Map<string, number>();
  for (const e of prevMonthExpenses) {
    prevByCat.set(e.category, (prevByCat.get(e.category) || 0) + e.amount);
  }

  const risingCategories: CategorySpikeInsight[] = [];
  for (const [category, curAmt] of curByCat.entries()) {
    const prevAmt = prevByCat.get(category) || 0;
    if (curAmt > prevAmt && curAmt > 0) {
      const delta = Math.round((curAmt - prevAmt) * 100) / 100;
      const pct =
        prevAmt > 0 ? Math.round(((curAmt - prevAmt) / prevAmt) * 100) : 100;
      risingCategories.push({
        category,
        currentAmount: Math.round(curAmt * 100) / 100,
        previousAmount: Math.round(prevAmt * 100) / 100,
        deltaAmount: delta,
        percentChange: pct,
      });
    }
  }
  risingCategories.sort((a, b) => b.deltaAmount - a.deltaAmount);

  // Top spending driver
  const topDriver =
    Array.from(curByCat.entries()).sort((a, b) => b[1] - a[1])[0]?.[0] || null;

  // Burn rate & end-of-month projection
  const [y, m] = activeMonth.split('-').map(Number);
  const daysInMonth = new Date(Date.UTC(y, m, 0)).getUTCDate();
  const maxDayInData = currentMonthExpenses.reduce((max, e) => {
    const day = Number(e.date.slice(8, 10)) || 1;
    return Math.max(max, day);
  }, 1);
  const today = new Date();
  const todayKey = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
  const elapsedDays =
    activeMonth === todayKey ? Math.max(today.getDate(), maxDayInData) : maxDayInData;

  const dailyBurnRate =
    currentTotal > 0 ? Math.round((currentTotal / Math.max(elapsedDays, 1)) * 100) / 100 : 0;
  const projectedMonthEndSpend =
    activeMonth === todayKey
      ? Math.round(dailyBurnRate * daysInMonth * 100) / 100
      : currentTotal;

  // Weighted 3-month moving average for next month forecast
  const monthTotalsMap = new Map<string, number>();
  for (const e of expenses) {
    const mk = e.date.slice(0, 7);
    monthTotalsMap.set(mk, (monthTotalsMap.get(mk) || 0) + e.amount);
  }
  const sortedMonths = Array.from(monthTotalsMap.entries())
    .sort((a, b) => a[0].localeCompare(b[0]))
    .slice(-3);

  let nextMonthForecast = currentTotal;
  if (sortedMonths.length > 0) {
    let weightedSum = 0;
    let totalWeight = 0;
    sortedMonths.forEach(([, val], index) => {
      const weight = index + 1; // more recent months carry higher weight
      weightedSum += val * weight;
      totalWeight += weight;
    });
    nextMonthForecast = Math.round((weightedSum / totalWeight) * 100) / 100;
  }

  const savingsRatePercent =
    currentIncome > 0
      ? Math.round(((currentIncome - currentTotal) / currentIncome) * 1000) / 10
      : null;

  return {
    projectedMonthEndSpend,
    nextMonthForecast,
    dailyBurnRate,
    monthsAnalyzed: monthTotalsMap.size,
    topDriverCategory: topDriver,
    risingCategories,
    savingsRatePercent,
  };
}
