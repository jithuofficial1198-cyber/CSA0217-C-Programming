import type {
  CurrencyCode,
  ExpenseRecord,
  IncomeRecord,
  RecurringFrequency,
  RecurringRule,
  SavingsGoal,
  ThemeMode,
  UserPreferences,
  UserProfile,
  WorkspacePayload,
} from '../types/finance';

const TOKEN_STORAGE_KEY = 'ledgerflow_session_token';

export function getStoredToken(): string | null {
  try {
    return localStorage.getItem(TOKEN_STORAGE_KEY);
  } catch {
    return null;
  }
}

export function setStoredToken(token: string | null): void {
  try {
    if (token) {
      localStorage.setItem(TOKEN_STORAGE_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_STORAGE_KEY);
    }
  } catch {
    // Ignore storage errors in restricted environments
  }
}

async function apiRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(options.headers);
  if (options.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(path, {
    ...options,
    headers,
    credentials: 'include',
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message =
      (data && typeof data.error === 'string' && data.error) ||
      `Request failed (${response.status})`;
    throw new Error(message);
  }
  return data as T;
}

export async function registerUser(input: {
  name: string;
  email: string;
  password: string;
}): Promise<{ token: string; user: UserProfile; preferences: UserPreferences }> {
  const result = await apiRequest<{
    token: string;
    user: UserProfile;
    preferences: UserPreferences;
  }>('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify(input),
  });
  setStoredToken(result.token);
  return result;
}

export async function loginUser(input: {
  email: string;
  password: string;
}): Promise<{ token: string; user: UserProfile; preferences: UserPreferences }> {
  const result = await apiRequest<{
    token: string;
    user: UserProfile;
    preferences: UserPreferences;
  }>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify(input),
  });
  setStoredToken(result.token);
  return result;
}

export async function logoutUser(): Promise<void> {
  try {
    await apiRequest('/api/auth/logout', { method: 'POST' });
  } finally {
    setStoredToken(null);
  }
}

export async function fetchWorkspace(): Promise<WorkspacePayload> {
  return apiRequest<WorkspacePayload>('/api/workspace');
}

export async function updateProfile(input: {
  name?: string;
  email?: string;
  currentPassword?: string;
  newPassword?: string;
}): Promise<{ user: UserProfile }> {
  return apiRequest<{ user: UserProfile }>('/api/auth/profile', {
    method: 'PUT',
    body: JSON.stringify(input),
  });
}

export async function updatePreferences(input: {
  currency?: CurrencyCode;
  theme?: ThemeMode;
  monthlyBudget?: number;
  categoryLimits?: Record<string, number>;
  customCategories?: string[];
}): Promise<{ preferences: UserPreferences }> {
  return apiRequest<{ preferences: UserPreferences }>('/api/preferences', {
    method: 'PUT',
    body: JSON.stringify(input),
  });
}

export async function createIncome(input: {
  amount: number;
  source: string;
  description: string;
  date: string;
}): Promise<{ income: IncomeRecord }> {
  return apiRequest<{ income: IncomeRecord }>('/api/incomes', {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

export async function updateIncome(
  id: string,
  input: Partial<Pick<IncomeRecord, 'amount' | 'source' | 'description' | 'date'>>
): Promise<{ income: IncomeRecord }> {
  return apiRequest<{ income: IncomeRecord }>(`/api/incomes/${id}`, {
    method: 'PUT',
    body: JSON.stringify(input),
  });
}

export async function deleteIncome(id: string): Promise<void> {
  await apiRequest(`/api/incomes/${id}`, { method: 'DELETE' });
}

export async function createExpense(input: {
  amount: number;
  category: string;
  paymentMethod: string;
  note: string;
  date: string;
}): Promise<{ expense: ExpenseRecord }> {
  return apiRequest<{ expense: ExpenseRecord }>('/api/expenses', {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

export async function updateExpense(
  id: string,
  input: Partial<Pick<ExpenseRecord, 'amount' | 'category' | 'paymentMethod' | 'note' | 'date'>>
): Promise<{ expense: ExpenseRecord }> {
  return apiRequest<{ expense: ExpenseRecord }>(`/api/expenses/${id}`, {
    method: 'PUT',
    body: JSON.stringify(input),
  });
}

export async function deleteExpense(id: string): Promise<void> {
  await apiRequest(`/api/expenses/${id}`, { method: 'DELETE' });
}

export async function createRecurringRule(input: {
  title: string;
  amount: number;
  category: string;
  paymentMethod: string;
  frequency: RecurringFrequency;
  nextDueDate: string;
}): Promise<{ recurringRule: RecurringRule }> {
  return apiRequest<{ recurringRule: RecurringRule }>('/api/recurring', {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

export async function toggleRecurringRule(
  id: string,
  active: boolean
): Promise<{ recurringRule: RecurringRule }> {
  return apiRequest<{ recurringRule: RecurringRule }>(`/api/recurring/${id}`, {
    method: 'PUT',
    body: JSON.stringify({ active }),
  });
}

export async function logRecurringExpense(
  id: string,
  date?: string
): Promise<{ expense: ExpenseRecord; recurringRule: RecurringRule }> {
  return apiRequest<{ expense: ExpenseRecord; recurringRule: RecurringRule }>(
    `/api/recurring/${id}/log`,
    {
      method: 'POST',
      body: JSON.stringify({ date }),
    }
  );
}

export async function deleteRecurringRule(id: string): Promise<void> {
  await apiRequest(`/api/recurring/${id}`, { method: 'DELETE' });
}

export async function createSavingsGoal(input: {
  title: string;
  targetAmount: number;
  savedAmount: number;
  deadline: string;
}): Promise<{ goal: SavingsGoal }> {
  return apiRequest<{ goal: SavingsGoal }>('/api/goals', {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

export async function contributeSavingsGoal(
  id: string,
  delta: number
): Promise<{ goal: SavingsGoal }> {
  return apiRequest<{ goal: SavingsGoal }>(`/api/goals/${id}/contribute`, {
    method: 'POST',
    body: JSON.stringify({ delta }),
  });
}

export async function deleteSavingsGoal(id: string): Promise<void> {
  await apiRequest(`/api/goals/${id}`, { method: 'DELETE' });
}
