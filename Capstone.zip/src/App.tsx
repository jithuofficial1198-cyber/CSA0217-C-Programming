import { useCallback, useEffect, useMemo, useState } from 'react';
import type {
  CurrencyCode,
  ExpenseRecord,
  IncomeRecord,
  RecurringFrequency,
  RecurringRule,
  SavingsGoal,
  ThemeMode,
  UserPreferences,
  UserProfile,
  WorkspaceTab,
} from './types/finance';
import {
  contributeSavingsGoal,
  createExpense,
  createIncome,
  createRecurringRule,
  createSavingsGoal,
  deleteExpense,
  deleteIncome,
  deleteRecurringRule,
  deleteSavingsGoal,
  fetchWorkspace,
  getStoredToken,
  logRecurringExpense,
  logoutUser,
  toggleRecurringRule,
  updateExpense,
  updateIncome,
  updatePreferences,
  updateProfile,
} from './services/api';
import { DEFAULT_EXPENSE_CATEGORIES } from './utils/calculations';
import { AuthView } from './components/AuthView';
import { AppShell } from './components/AppShell';
import { OverviewView } from './components/OverviewView';
import { IncomeView } from './components/IncomeView';
import { ExpensesView } from './components/ExpensesView';
import { BudgetsAndGoalsView } from './components/BudgetsAndGoalsView';
import { ReportsAndInsightsView } from './components/ReportsAndInsightsView';
import { SettingsAndProfileView } from './components/SettingsAndProfileView';

export default function App() {
  const [bootstrapping, setBootstrapping] = useState(true);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [preferences, setPreferences] = useState<UserPreferences | null>(null);
  const [guestTheme, setGuestTheme] = useState<ThemeMode>('light');
  const [incomes, setIncomes] = useState<IncomeRecord[]>([]);
  const [expenses, setExpenses] = useState<ExpenseRecord[]>([]);
  const [recurringRules, setRecurringRules] = useState<RecurringRule[]>([]);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>([]);

  const [activeTab, setActiveTab] = useState<WorkspaceTab>('overview');
  const [selectedMonth, setSelectedMonth] = useState(() =>
    new Date().toISOString().slice(0, 7)
  );
  const [toast, setToast] = useState<string | null>(null);

  const activeTheme: ThemeMode = preferences?.theme || guestTheme;

  useEffect(() => {
    const root = document.documentElement;
    if (activeTheme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [activeTheme]);

  const showToast = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => {
      setToast((current) => (current === message ? null : current));
    }, 2600);
  }, []);

  const hydrateWorkspace = useCallback(async () => {
    const token = getStoredToken();
    if (!token) {
      setBootstrapping(false);
      return;
    }
    try {
      const data = await fetchWorkspace();
      setUser(data.user);
      setPreferences(data.preferences);
      setIncomes(data.incomes);
      setExpenses(data.expenses);
      setRecurringRules(data.recurringRules);
      setSavingsGoals(data.savingsGoals);
    } catch {
      setUser(null);
      setPreferences(null);
    } finally {
      setBootstrapping(false);
    }
  }, []);

  useEffect(() => {
    void hydrateWorkspace();
  }, [hydrateWorkspace]);

  const categories = useMemo(() => {
    const custom = preferences?.customCategories || [];
    return Array.from(new Set([...DEFAULT_EXPENSE_CATEGORIES, ...custom]));
  }, [preferences?.customCategories]);

  async function handleAuthenticated(payload: {
    user: UserProfile;
    preferences: UserPreferences;
  }) {
    setUser(payload.user);
    setPreferences(payload.preferences);
    setBootstrapping(true);
    try {
      const data = await fetchWorkspace();
      setUser(data.user);
      setPreferences(data.preferences);
      setIncomes(data.incomes);
      setExpenses(data.expenses);
      setRecurringRules(data.recurringRules);
      setSavingsGoals(data.savingsGoals);
    } finally {
      setBootstrapping(false);
    }
  }

  async function handleLogout() {
    await logoutUser();
    setUser(null);
    setPreferences(null);
    setIncomes([]);
    setExpenses([]);
    setRecurringRules([]);
    setSavingsGoals([]);
    setActiveTab('overview');
  }

  async function handleToggleTheme() {
    const nextTheme: ThemeMode = activeTheme === 'dark' ? 'light' : 'dark';
    if (!user || !preferences) {
      setGuestTheme(nextTheme);
      return;
    }
    setPreferences({ ...preferences, theme: nextTheme });
    const res = await updatePreferences({ theme: nextTheme });
    setPreferences(res.preferences);
  }

  async function handleSavePreferences(input: {
    currency?: CurrencyCode;
    theme?: ThemeMode;
    monthlyBudget?: number;
    categoryLimits?: Record<string, number>;
    customCategories?: string[];
  }) {
    const res = await updatePreferences(input);
    setPreferences(res.preferences);
  }

  async function handleUpdateProfile(input: {
    name?: string;
    email?: string;
    currentPassword?: string;
    newPassword?: string;
  }) {
    const res = await updateProfile(input);
    setUser(res.user);
  }

  async function handleAddIncome(input: {
    amount: number;
    source: string;
    description: string;
    date: string;
  }) {
    const res = await createIncome(input);
    setIncomes((prev) =>
      [res.income, ...prev].sort((a, b) => b.date.localeCompare(a.date))
    );
    showToast('Income recorded.');
  }

  async function handleUpdateIncome(
    id: string,
    input: Partial<Pick<IncomeRecord, 'amount' | 'source' | 'description' | 'date'>>
  ) {
    const res = await updateIncome(id, input);
    setIncomes((prev) =>
      prev
        .map((item) => (item.id === id ? res.income : item))
        .sort((a, b) => b.date.localeCompare(a.date))
    );
    showToast('Income updated.');
  }

  async function handleDeleteIncome(id: string) {
    await deleteIncome(id);
    setIncomes((prev) => prev.filter((item) => item.id !== id));
    showToast('Income deleted.');
  }

  async function handleAddExpense(input: {
    amount: number;
    category: string;
    paymentMethod: string;
    note: string;
    date: string;
  }) {
    const res = await createExpense(input);
    setExpenses((prev) =>
      [res.expense, ...prev].sort((a, b) => b.date.localeCompare(a.date))
    );
    showToast('Expense added.');
  }

  async function handleUpdateExpense(
    id: string,
    input: Partial<
      Pick<ExpenseRecord, 'amount' | 'category' | 'paymentMethod' | 'note' | 'date'>
    >
  ) {
    const res = await updateExpense(id, input);
    setExpenses((prev) =>
      prev
        .map((item) => (item.id === id ? res.expense : item))
        .sort((a, b) => b.date.localeCompare(a.date))
    );
    showToast('Expense updated.');
  }

  async function handleDeleteExpense(id: string) {
    await deleteExpense(id);
    setExpenses((prev) => prev.filter((item) => item.id !== id));
    showToast('Expense removed.');
  }

  async function handleCreateRecurring(input: {
    title: string;
    amount: number;
    category: string;
    paymentMethod: string;
    frequency: RecurringFrequency;
    nextDueDate: string;
  }) {
    const res = await createRecurringRule(input);
    setRecurringRules((prev) => [...prev, res.recurringRule]);
    showToast('Recurring bill added.');
  }

  async function handleToggleRecurring(id: string, active: boolean) {
    const res = await toggleRecurringRule(id, active);
    setRecurringRules((prev) =>
      prev.map((item) => (item.id === id ? res.recurringRule : item))
    );
  }

  async function handleLogRecurring(id: string, date: string) {
    const res = await logRecurringExpense(id, date);
    setExpenses((prev) =>
      [res.expense, ...prev].sort((a, b) => b.date.localeCompare(a.date))
    );
    setRecurringRules((prev) =>
      prev.map((item) => (item.id === id ? res.recurringRule : item))
    );
    showToast('Recurring bill logged as expense.');
  }

  async function handleDeleteRecurring(id: string) {
    await deleteRecurringRule(id);
    setRecurringRules((prev) => prev.filter((item) => item.id !== id));
    showToast('Recurring bill deleted.');
  }

  async function handleCreateGoal(input: {
    title: string;
    targetAmount: number;
    savedAmount: number;
    deadline: string;
  }) {
    const res = await createSavingsGoal(input);
    setSavingsGoals((prev) => [...prev, res.goal]);
    showToast('Savings goal created.');
  }

  async function handleContributeGoal(id: string, delta: number) {
    const res = await contributeSavingsGoal(id, delta);
    setSavingsGoals((prev) =>
      prev.map((item) => (item.id === id ? res.goal : item))
    );
    showToast('Savings goal updated.');
  }

  async function handleDeleteGoal(id: string) {
    await deleteSavingsGoal(id);
    setSavingsGoals((prev) => prev.filter((item) => item.id !== id));
    showToast('Savings goal deleted.');
  }

  if (bootstrapping) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 p-8 flex items-center justify-center">
        <div className="w-full max-w-md space-y-3">
          <div className="h-6 w-36 bg-slate-200 dark:bg-slate-800 rounded animate-pulse" />
          <div className="h-28 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl animate-pulse" />
          <div className="h-28 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl animate-pulse" />
        </div>
      </div>
    );
  }

  if (!user || !preferences) {
    return (
      <AuthView
        theme={activeTheme}
        onToggleTheme={() => void handleToggleTheme()}
        onAuthenticated={(payload) => void handleAuthenticated(payload)}
      />
    );
  }

  return (
    <>
      <AppShell
        user={user}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        selectedMonth={selectedMonth}
        onApplyMonth={setSelectedMonth}
        theme={preferences.theme}
        onToggleTheme={() => void handleToggleTheme()}
        onLogout={() => void handleLogout()}
      >
        {activeTab === 'overview' && (
          <OverviewView
            selectedMonth={selectedMonth}
            preferences={preferences}
            categories={categories}
            incomes={incomes}
            expenses={expenses}
            onAddExpense={handleAddExpense}
            onAddIncome={handleAddIncome}
            onDeleteExpense={handleDeleteExpense}
            onDeleteIncome={handleDeleteIncome}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'income' && (
          <IncomeView
            selectedMonth={selectedMonth}
            currency={preferences.currency}
            incomes={incomes}
            onAddIncome={handleAddIncome}
            onUpdateIncome={handleUpdateIncome}
            onDeleteIncome={handleDeleteIncome}
          />
        )}

        {activeTab === 'expenses' && (
          <ExpensesView
            selectedMonth={selectedMonth}
            currency={preferences.currency}
            categories={categories}
            expenses={expenses}
            onAddExpense={handleAddExpense}
            onUpdateExpense={handleUpdateExpense}
            onDeleteExpense={handleDeleteExpense}
          />
        )}

        {activeTab === 'budgets' && (
          <BudgetsAndGoalsView
            selectedMonth={selectedMonth}
            preferences={preferences}
            categories={categories}
            expenses={expenses}
            recurringRules={recurringRules}
            savingsGoals={savingsGoals}
            onSaveBudgetSettings={handleSavePreferences}
            onCreateRecurring={handleCreateRecurring}
            onToggleRecurring={handleToggleRecurring}
            onLogRecurring={handleLogRecurring}
            onDeleteRecurring={handleDeleteRecurring}
            onCreateGoal={handleCreateGoal}
            onContributeGoal={handleContributeGoal}
            onDeleteGoal={handleDeleteGoal}
          />
        )}

        {activeTab === 'reports' && (
          <ReportsAndInsightsView
            selectedMonth={selectedMonth}
            currency={preferences.currency}
            incomes={incomes}
            expenses={expenses}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsAndProfileView
            user={user}
            preferences={preferences}
            onSavePreferences={handleSavePreferences}
            onUpdateProfile={handleUpdateProfile}
          />
        )}
      </AppShell>

      {toast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 px-4 py-2.5 text-xs font-medium text-white bg-slate-900 dark:bg-slate-800 border border-slate-700 rounded-lg shadow-lg"
        >
          {toast}
        </div>
      )}
    </>
  );
}
