export type CurrencyCode = 'INR' | 'USD' | 'EUR' | 'GBP';
export type ThemeMode = 'light' | 'dark';
export type RecurringFrequency = 'weekly' | 'monthly' | 'yearly';

export type WorkspaceTab =
  | 'overview'
  | 'income'
  | 'expenses'
  | 'budgets'
  | 'reports'
  | 'settings';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  createdAt: string;
}

export interface UserPreferences {
  userId: string;
  currency: CurrencyCode;
  theme: ThemeMode;
  monthlyBudget: number;
  categoryLimits: Record<string, number>;
  customCategories: string[];
}

export interface IncomeRecord {
  id: string;
  userId: string;
  amount: number;
  source: string;
  description: string;
  date: string;
  createdAt: string;
}

export interface ExpenseRecord {
  id: string;
  userId: string;
  amount: number;
  category: string;
  paymentMethod: string;
  note: string;
  date: string;
  recurringId?: string;
  createdAt: string;
}

export interface RecurringRule {
  id: string;
  userId: string;
  title: string;
  amount: number;
  category: string;
  paymentMethod: string;
  frequency: RecurringFrequency;
  nextDueDate: string;
  active: boolean;
  lastLoggedMonth?: string;
  createdAt: string;
}

export interface SavingsGoal {
  id: string;
  userId: string;
  title: string;
  targetAmount: number;
  savedAmount: number;
  deadline: string;
  createdAt: string;
}

export interface WorkspacePayload {
  user: UserProfile;
  preferences: UserPreferences;
  incomes: IncomeRecord[];
  expenses: ExpenseRecord[];
  recurringRules: RecurringRule[];
  savingsGoals: SavingsGoal[];
}

export type BudgetHealthStatus = 'healthy' | 'warning' | 'exceeded' | 'unconfigured';

export interface CategoryBudgetProgress {
  category: string;
  spent: number;
  limit: number | null;
  percentage: number;
  status: BudgetHealthStatus;
}

export interface CategorySpikeInsight {
  category: string;
  currentAmount: number;
  previousAmount: number;
  deltaAmount: number;
  percentChange: number;
}

export interface SpendingPrediction {
  projectedMonthEndSpend: number;
  nextMonthForecast: number;
  dailyBurnRate: number;
  monthsAnalyzed: number;
  topDriverCategory: string | null;
  risingCategories: CategorySpikeInsight[];
  savingsRatePercent: number | null;
}
