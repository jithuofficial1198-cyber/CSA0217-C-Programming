import { useState, type FormEvent } from 'react';
import { Download, Pencil, Plus, Search, Trash2, X } from 'lucide-react';
import type { CurrencyCode, ExpenseRecord } from '../types/finance';
import {
  calculateExpense,
  formatCurrencyExact,
  getMonthLabel,
  PAYMENT_METHODS,
} from '../utils/calculations';

interface ExpensesViewProps {
  selectedMonth: string;
  currency: CurrencyCode;
  categories: string[];
  expenses: ExpenseRecord[];
  onAddExpense: (input: {
    amount: number;
    category: string;
    paymentMethod: string;
    note: string;
    date: string;
  }) => Promise<void>;
  onUpdateExpense: (
    id: string,
    input: Partial<Pick<ExpenseRecord, 'amount' | 'category' | 'paymentMethod' | 'note' | 'date'>>
  ) => Promise<void>;
  onDeleteExpense: (id: string) => Promise<void>;
}

export function ExpensesView({
  selectedMonth,
  currency,
  categories,
  expenses,
  onAddExpense,
  onUpdateExpense,
  onDeleteExpense,
}: ExpensesViewProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState(categories[0] || 'Food');
  const [paymentMethod, setPaymentMethod] = useState(PAYMENT_METHODS[0]);
  const [note, setNote] = useState('');
  const [date, setDate] = useState(`${selectedMonth}-18`);

  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('ALL');
  const [filterPayment, setFilterPayment] = useState('ALL');
  const [scope, setScope] = useState<'month' | 'all'>('month');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const filtered = expenses.filter((item) => {
    if (scope === 'month' && !item.date.startsWith(selectedMonth)) return false;
    if (filterCategory !== 'ALL' && item.category !== filterCategory) return false;
    if (filterPayment !== 'ALL' && item.paymentMethod !== filterPayment) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      const matchesNote = item.note.toLowerCase().includes(q);
      const matchesCat = item.category.toLowerCase().includes(q);
      const matchesDate = item.date.includes(q);
      if (!matchesNote && !matchesCat && !matchesDate) return false;
    }
    return true;
  });

  const filteredTotal = calculateExpense(filtered);

  function startEdit(record: ExpenseRecord) {
    setEditingId(record.id);
    setAmount(String(record.amount));
    setCategory(record.category);
    setPaymentMethod(record.paymentMethod);
    setNote(record.note);
    setDate(record.date);
    setError(null);
  }

  function resetForm() {
    setEditingId(null);
    setAmount('');
    setCategory(categories[0] || 'Food');
    setPaymentMethod(PAYMENT_METHODS[0]);
    setNote('');
    setDate(`${selectedMonth}-18`);
    setError(null);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    const num = Number(amount);
    if (!Number.isFinite(num) || num <= 0) {
      setError('Expense amount must be greater than zero.');
      return;
    }
    setSubmitting(true);
    try {
      if (editingId) {
        await onUpdateExpense(editingId, {
          amount: num,
          category,
          paymentMethod,
          note,
          date,
        });
      } else {
        await onAddExpense({
          amount: num,
          category,
          paymentMethod,
          note,
          date,
        });
      }
      resetForm();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save expense.');
    } finally {
      setSubmitting(false);
    }
  }

  function handleExportCsv() {
    const header = ['Date', 'Category', 'Payment Method', 'Note', 'Amount'];
    const rows = filtered.map((e) => [
      e.date,
      `"${e.category.replace(/"/g, '""')}"`,
      `"${e.paymentMethod.replace(/"/g, '""')}"`,
      `"${e.note.replace(/"/g, '""')}"`,
      e.amount.toFixed(2),
    ]);
    const csvContent = [header.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `expenses_${scope === 'month' ? selectedMonth : 'all'}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Record / Edit Expense Form */}
      <section className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            {editingId ? 'Edit Expense' : 'Record Expense'}
          </h2>
          {editingId && (
            <button
              type="button"
              onClick={resetForm}
              className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 inline-flex items-center gap-1"
            >
              <X className="h-3.5 w-3.5" />
              Cancel
            </button>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label
              htmlFor="exp-amount"
              className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
            >
              Amount
            </label>
            <input
              id="exp-amount"
              type="number"
              step="0.01"
              min="0.01"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
              className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>

          <div>
            <label
              htmlFor="exp-category"
              className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
            >
              Category
            </label>
            <select
              id="exp-category"
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="exp-method"
                className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
              >
                Payment Method
              </label>
              <select
                id="exp-method"
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {PAYMENT_METHODS.map((pm) => (
                  <option key={pm} value={pm}>
                    {pm}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label
                htmlFor="exp-date"
                className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
              >
                Date
              </label>
              <input
                id="exp-date"
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="exp-note"
              className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
            >
              Description / Note
            </label>
            <input
              id="exp-note"
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Optional description"
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
          </div>

          {error && (
            <p className="text-xs font-medium text-rose-600 dark:text-rose-400">{error}</p>
          )}

          <button
            type="submit"
            disabled={submitting}
            className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap"
          >
            <Plus className="h-4 w-4" />
            {submitting ? 'Saving...' : editingId ? 'Update Expense' : 'Add Expense'}
          </button>
        </form>
      </section>

      {/* Search, Filter & Expense Table */}
      <section className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Expenses Ledger
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono tabular-nums">
                {filtered.length} entries · Total: {formatCurrencyExact(filteredTotal, currency)}
              </p>
            </div>
            <button
              type="button"
              onClick={handleExportCsv}
              disabled={filtered.length === 0}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 disabled:opacity-50 rounded-lg transition-colors whitespace-nowrap"
            >
              <Download className="h-3.5 w-3.5" />
              Export CSV
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5">
            <div className="sm:col-span-5 relative">
              <Search className="h-3.5 w-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search note, category, or YYYY-MM-DD"
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <select
              aria-label="Filter by category"
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="sm:col-span-3 px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200"
            >
              <option value="ALL">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>

            <select
              aria-label="Filter by payment method"
              value={filterPayment}
              onChange={(e) => setFilterPayment(e.target.value)}
              className="sm:col-span-2 px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200"
            >
              <option value="ALL">All Methods</option>
              {PAYMENT_METHODS.map((pm) => (
                <option key={pm} value={pm}>
                  {pm}
                </option>
              ))}
            </select>

            <div className="sm:col-span-2 flex items-center gap-1 p-0.5 bg-slate-100 dark:bg-slate-800 rounded-lg">
              <button
                type="button"
                onClick={() => setScope('month')}
                className={`flex-1 py-1 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap ${
                  scope === 'month'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Month
              </button>
              <button
                type="button"
                onClick={() => setScope('all')}
                className={`flex-1 py-1 text-[11px] font-medium rounded-md transition-colors whitespace-nowrap ${
                  scope === 'all'
                    ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                All
              </button>
            </div>
          </div>
        </div>

        {filtered.length === 0 ? (
          <div className="px-5 py-12 text-center">
            <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
              No expenses found for {scope === 'month' ? getMonthLabel(selectedMonth) : 'this filter'}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Adjust your search filters or log a new expense on the left.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-900">
                  <th className="py-2.5 px-5">Date</th>
                  <th className="py-2.5 px-4">Category</th>
                  <th className="py-2.5 px-4">Method</th>
                  <th className="py-2.5 px-4">Note</th>
                  <th className="py-2.5 px-4 text-right">Amount</th>
                  <th className="py-2.5 px-5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                {filtered.map((item) => (
                  <tr
                    key={item.id}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-2.5 px-5 font-mono text-xs text-slate-600 dark:text-slate-400 tabular-nums whitespace-nowrap">
                      {item.date}
                    </td>
                    <td className="py-2.5 px-4 font-medium text-slate-900 dark:text-slate-100 whitespace-nowrap">
                      {item.category}
                    </td>
                    <td className="py-2.5 px-4 text-xs text-slate-500 dark:text-slate-400 whitespace-nowrap">
                      {item.paymentMethod}
                    </td>
                    <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300 max-w-xs truncate">
                      {item.note || '—'}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono font-medium text-slate-900 dark:text-slate-100 tabular-nums whitespace-nowrap">
                      {formatCurrencyExact(item.amount, currency)}
                    </td>
                    <td className="py-2.5 px-5 text-right whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => startEdit(item)}
                        aria-label={`Edit ${item.category} expense`}
                        className="p-1.5 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 rounded-md transition-colors"
                      >
                        <Pencil className="h-3.5 w-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteExpense(item.id)}
                        aria-label={`Delete ${item.category} expense`}
                        className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-md transition-colors ml-1"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
