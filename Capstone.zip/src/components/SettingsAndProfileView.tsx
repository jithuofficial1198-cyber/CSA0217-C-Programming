import { useState, type FormEvent } from 'react';
import { Moon, Plus, Sun, Trash2 } from 'lucide-react';
import type {
  CurrencyCode,
  ThemeMode,
  UserPreferences,
  UserProfile,
} from '../types/finance';
import { CURRENCY_CONFIG, DEFAULT_EXPENSE_CATEGORIES } from '../utils/calculations';

interface SettingsAndProfileViewProps {
  user: UserProfile;
  preferences: UserPreferences;
  onSavePreferences: (input: {
    currency?: CurrencyCode;
    theme?: ThemeMode;
    monthlyBudget?: number;
    customCategories?: string[];
  }) => Promise<void>;
  onUpdateProfile: (input: {
    name?: string;
    email?: string;
    currentPassword?: string;
    newPassword?: string;
  }) => Promise<void>;
}

export function SettingsAndProfileView({
  user,
  preferences,
  onSavePreferences,
  onUpdateProfile,
}: SettingsAndProfileViewProps) {
  const [currency, setCurrency] = useState<CurrencyCode>(preferences.currency);
  const [monthlyBudget, setMonthlyBudget] = useState(String(preferences.monthlyBudget));
  const [newCategory, setNewCategory] = useState('');
  const [prefStatus, setPrefStatus] = useState<string | null>(null);

  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [profileStatus, setProfileStatus] = useState<string | null>(null);
  const [profileError, setProfileError] = useState<string | null>(null);

  async function handlePreferencesSubmit(e: FormEvent) {
    e.preventDefault();
    setPrefStatus(null);
    const numBudget = Number(monthlyBudget);
    await onSavePreferences({
      currency,
      monthlyBudget: Number.isFinite(numBudget) && numBudget >= 0 ? numBudget : 0,
    });
    setPrefStatus('Preferences saved to your account.');
    setTimeout(() => setPrefStatus(null), 2500);
  }

  async function handleAddCustomCategory(e: FormEvent) {
    e.preventDefault();
    const clean = newCategory.trim();
    if (!clean) return;
    const exists = [...DEFAULT_EXPENSE_CATEGORIES, ...preferences.customCategories].some(
      (c) => c.toLowerCase() === clean.toLowerCase()
    );
    if (exists) {
      setPrefStatus('That category already exists.');
      return;
    }
    await onSavePreferences({
      customCategories: [...preferences.customCategories, clean],
    });
    setNewCategory('');
  }

  async function handleRemoveCustomCategory(cat: string) {
    await onSavePreferences({
      customCategories: preferences.customCategories.filter((c) => c !== cat),
    });
  }

  async function handleProfileSubmit(e: FormEvent) {
    e.preventDefault();
    setProfileError(null);
    setProfileStatus(null);
    try {
      await onUpdateProfile({
        name,
        email,
        currentPassword: newPassword ? currentPassword : undefined,
        newPassword: newPassword || undefined,
      });
      setCurrentPassword('');
      setNewPassword('');
      setProfileStatus('Account profile updated.');
      setTimeout(() => setProfileStatus(null), 2500);
    } catch (err) {
      setProfileError(err instanceof Error ? err.message : 'Unable to update profile.');
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Module 6: Personalisation */}
      <section className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-6">
        <div>
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            Personalisation &amp; Display
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Settings are saved to your account and restored across sessions.
          </p>
        </div>

        <form onSubmit={handlePreferencesSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="set-currency"
                className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
              >
                Preferred Currency
              </label>
              <select
                id="set-currency"
                value={currency}
                onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              >
                {(Object.keys(CURRENCY_CONFIG) as CurrencyCode[]).map((code) => (
                  <option key={code} value={code}>
                    {CURRENCY_CONFIG[code].label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <span className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1">
                Display Theme
              </span>
              <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg">
                <button
                  type="button"
                  onClick={() => onSavePreferences({ theme: 'light' })}
                  className={`flex-1 inline-flex items-center justify-center gap-1.5 py-1.5 text-xs font-medium rounded-md transition-colors ${
                    preferences.theme === 'light'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <Sun className="h-3.5 w-3.5" />
                  Light
                </button>
                <button
                  type="button"
                  onClick={() => onSavePreferences({ theme: 'dark' })}
                  className={`flex-1 inline-flex items-center justify-center gap-1.5 py-1.5 text-xs font-medium rounded-md transition-colors ${
                    preferences.theme === 'dark'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  <Moon className="h-3.5 w-3.5" />
                  Dark
                </button>
              </div>
            </div>
          </div>

          <div>
            <label
              htmlFor="set-budget"
              className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
            >
              Default Monthly Budget
            </label>
            <input
              id="set-budget"
              type="number"
              step="0.01"
              min="0"
              value={monthlyBudget}
              onChange={(e) => setMonthlyBudget(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="flex items-center justify-between gap-3">
            {prefStatus ? (
              <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
                {prefStatus}
              </span>
            ) : (
              <span />
            )}
            <button
              type="submit"
              className="px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap"
            >
              Save Settings
            </button>
          </div>
        </form>

        {/* Custom Categories */}
        <div className="pt-5 border-t border-slate-200 dark:border-slate-800 space-y-3">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
            Custom Expense Categories
          </h3>
          <form onSubmit={handleAddCustomCategory} className="flex gap-2">
            <input
              type="text"
              value={newCategory}
              onChange={(e) => setNewCategory(e.target.value)}
              placeholder="Add category (e.g. Subscriptions, Travel)"
              maxLength={32}
              className="flex-1 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
            />
            <button
              type="submit"
              className="inline-flex items-center gap-1 px-3.5 py-2 text-xs font-medium text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors whitespace-nowrap"
            >
              <Plus className="h-3.5 w-3.5" />
              Add
            </button>
          </form>

          {preferences.customCategories.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Using default categories: {DEFAULT_EXPENSE_CATEGORIES.join(', ')}.
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {preferences.customCategories.map((cat) => (
                <div key={cat} className="py-2 flex items-center justify-between text-sm">
                  <span className="text-slate-800 dark:text-slate-200">{cat}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveCustomCategory(cat)}
                    aria-label={`Remove custom category ${cat}`}
                    className="p-1 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Module 1: Profile Management */}
      <section className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-5">
        <div>
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            Profile &amp; Account Security
          </h2>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            Update your display name, email address, or account password.
          </p>
        </div>

        <form onSubmit={handleProfileSubmit} className="space-y-4">
          <div>
            <label
              htmlFor="prof-name"
              className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
            >
              Display Name
            </label>
            <input
              id="prof-name"
              type="text"
              required
              minLength={2}
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
            />
          </div>

          <div>
            <label
              htmlFor="prof-email"
              className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
            >
              Account Email
            </label>
            <input
              id="prof-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
            />
          </div>

          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
            <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              Change Password (optional)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="password"
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                placeholder="Current password"
                className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              />
              <input
                type="password"
                minLength={6}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="New password (6+ chars)"
                className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>

          {profileError && (
            <p className="text-xs font-medium text-rose-600 dark:text-rose-400">
              {profileError}
            </p>
          )}

          <div className="flex items-center justify-between gap-3">
            {profileStatus ? (
              <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
                {profileStatus}
              </span>
            ) : (
              <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                ID: {user.id}
              </span>
            )}
            <button
              type="submit"
              className="px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap"
            >
              Update Profile
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}
