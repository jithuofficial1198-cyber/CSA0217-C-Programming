import { useState, type FormEvent } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Plus,
  Trash2,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
} from 'lucide-react';
import type {
  CurrencyCode,
  ExpenseRecord,
  IncomeRecord,
  UserPreferences,
  WorkspaceTab,
} from '../types/finance';
import {
  calculateBalance,
  calculateExpense,
  calculateIncome,
  computeCategoryBudgets,
  computeInsightsAndForecast,
  evaluateBudgetStatus,
  formatCurrency,
  formatCurrencyExact,
  getMonthLabel,
  groupExpensesByCategory,
  INCOME_SOURCES,
  PAYMENT_METHODS,
} from '../utils/calculations';
import { DonutChart } from './Charts';

interface OverviewViewProps {
  selectedMonth: string;
  preferences: UserPreferences;
  categories: string[];
  incomes: IncomeRecord[];
  expenses: ExpenseRecord[];
  onAddExpense: (input: {
    amount: number;
    category: string;
    paymentMethod: string;
    note: string;
    date: string;
  }) => Promise<void>;
  onAddIncome: (input: {
    amount: number;
    source: string;
    description: string;
    date: string;
  }) => Promise<void>;
  onDeleteExpense: (id: string) => Promise<void>;
  onDeleteIncome: (id: string) => Promise<void>;
  onNavigateTab: (tab: WorkspaceTab) => void;
}

export function OverviewView({
  selectedMonth,
  preferences,
  categories,
  incomes,
  expenses,
  onAddExpense,
  onAddIncome,
  onDeleteExpense,
  onDeleteIncome,
  onNavigateTab,
}: OverviewViewProps) {
  const [entryMode, setEntryMode] = useState<'expense' | 'income'>('expense');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState(categories[0] || 'Food');
  const [paymentMethod, setPaymentMethod] = useState(PAYMENT_METHODS[0]);
  const [source, setSource] = useState(INCOME_SOURCES[0]);
  const [note, setNote] = useState('');
  const [date, setDate] = useState(`${selectedMonth}-18`);
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const currency: CurrencyCode = preferences.currency;
  const monthIncomes = incomes.filter((i) => i.date.startsWith(selectedMonth));
  const monthExpenses = expenses.filter((e) => e.date.startsWith(selectedMonth));

  const totalIncome = calculateIncome(incomes, selectedMonth);
  const totalExpense = calculateExpense(expenses, selectedMonth);
  const availableBalance = calculateBalance(totalIncome, totalExpense);
  const budgetEval = evaluateBudgetStatus(totalExpense, preferences.monthlyBudget);

  const categorySlices = groupExpensesByCategory(expenses, selectedMonth);
  const categoryBudgets = computeCategoryBudgets(
    expenses,
    preferences.categoryLimits,
    selectedMonth
  );
  const insights = computeInsightsAndForecast(incomes, expenses, selectedMonth);

  const exceededCategories = categoryBudgets.filter((c) => c.status === 'exceeded');
  const warningCategories = categoryBudgets.filter((c) => c.status === 'warning');

  const recentActivity = [
    ...monthExpenses.map((e) => ({
      id: e.id,
      kind: 'expense' as const,
      date: e.date,
      label: e.category,
      sublabel: e.paymentMethod,
      note: e.note,
      amount: e.amount,
    })),
    ...monthIncomes.map((i) => ({
      id: i.id,
      kind: 'income' as const,
      date: i.date,
      label: i.source,
      sublabel: 'Income',
      note: i.description,
      amount: i.amount,
    })),
  ]
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 10);

  async function handleQuickSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    const num = Number(amount);
    if (!Number.isFinite(num) || num <= 0) {
      setFormError('Please enter a valid positive amount.');
      return;
    }
    setSubmitting(true);
    try {
      if (entryMode === 'expense') {
        await onAddExpense({
          amount: num,
          category,
          paymentMethod,
          note,
          date,
        });
      } else {
        await onAddIncome({
          amount: num,
          source,
          description: note,
          date,
        });
      }
      setAmount('');
      setNote('');
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Unable to save entry.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Module 4: Budget Alert Banner (80% Warning & >100% Exceeded) */}
      {(budgetEval.status === 'exceeded' ||
        budgetEval.status === 'warning' ||
        exceededCategories.length > 0 ||
        warningCategories.length > 0) && (
        <div
          role="alert"
          className={`flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-4 py-3 rounded-xl border ${
            budgetEval.status === 'exceeded' || exceededCategories.length > 0
              ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
              : 'bg-amber-50 dark:bg-amber-950/50 border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200'
          }`}
        >
          <div className="flex items-start sm:items-center gap-3">
            <AlertTriangle className="h-4 w-4 mt-0.5 sm:mt-0 shrink-0" />
            <div className="text-xs sm:text-sm">
              {budgetEval.status === 'exceeded' && (
                <p className="font-medium">
                  Exceeded Budget Alert: Monthly spending ({formatCurrency(totalExpense, currency)}) is at{' '}
                  <span className="font-mono tabular-nums">{budgetEval.percentage}%</span> of your{' '}
                  {formatCurrency(preferences.monthlyBudget, currency)} limit.
                </p>
              )}
              {budgetEval.status === 'warning' && (
                <p className="font-medium">
                  Budget Warning (80%+): You have used{' '}
                  <span className="font-mono tabular-nums">{budgetEval.percentage}%</span> of your{' '}
                  {getMonthLabel(selectedMonth)} monthly budget.
                </p>
              )}
              {exceededCategories.length > 0 && (
                <p className="mt-0.5 text-xs opacity-90">
                  Exceeded category limits:{' '}
                  {exceededCategories.map((c) => `${c.category} (${c.percentage}%)`).join(', ')}
                </p>
              )}
              {warningCategories.length > 0 && (
                <p className="mt-0.5 text-xs opacity-90">
                  Categories at 80%+:{' '}
                  {warningCategories.map((c) => `${c.category} (${c.percentage}%)`).join(', ')}
                </p>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={() => onNavigateTab('budgets')}
            className="text-xs font-medium underline underline-offset-2 whitespace-nowrap shrink-0 self-start sm:self-center"
          >
            Adjust Limits
          </button>
        </div>
      )}

      {/* 4-Column KPI Strip */}
      <section className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Total Income</span>
            <ArrowUpRight className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 dark:text-white tabular-nums">
            {formatCurrency(totalIncome, currency)}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {monthIncomes.length} entries · {getMonthLabel(selectedMonth)}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Total Expenses</span>
            <ArrowDownRight className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          </div>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 dark:text-white tabular-nums">
            {formatCurrency(totalExpense, currency)}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {monthExpenses.length} transactions · {getMonthLabel(selectedMonth)}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Available Balance</span>
            <CheckCircle2
              className={`h-4 w-4 ${
                availableBalance >= 0
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : 'text-rose-600 dark:text-rose-400'
              }`}
            />
          </div>
          <p
            className={`mt-2 font-mono text-2xl font-semibold tabular-nums ${
              availableBalance >= 0
                ? 'text-slate-900 dark:text-white'
                : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            {formatCurrency(availableBalance, currency)}
          </p>
          <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
            {insights.savingsRatePercent !== null
              ? `Net savings rate: ${insights.savingsRatePercent}%`
              : 'Income minus expenses'}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>Budget Status</span>
            <span
              className={`font-mono font-medium tabular-nums ${
                budgetEval.status === 'exceeded'
                  ? 'text-rose-600 dark:text-rose-400'
                  : budgetEval.status === 'warning'
                  ? 'text-amber-600 dark:text-amber-400'
                  : 'text-emerald-600 dark:text-emerald-400'
              }`}
            >
              {preferences.monthlyBudget > 0 ? `${budgetEval.percentage}% used` : 'No cap'}
            </span>
          </div>
          <p className="mt-2 font-mono text-sm font-semibold text-slate-900 dark:text-white tabular-nums">
            {preferences.monthlyBudget > 0
              ? `Left: ${formatCurrency(budgetEval.remaining, currency)}`
              : 'Set Monthly Limit'}
          </p>
          <div className="mt-2.5 h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-200 ${
                budgetEval.status === 'exceeded'
                  ? 'bg-rose-600'
                  : budgetEval.status === 'warning'
                  ? 'bg-amber-500'
                  : 'bg-emerald-600'
              }`}
              style={{ width: `${Math.min(100, budgetEval.percentage)}%` }}
            />
          </div>
          <p className="mt-1.5 font-mono text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
            Spent: {formatCurrencyExact(totalExpense, currency)} /{' '}
            {formatCurrency(preferences.monthlyBudget, currency)}
          </p>
        </div>
      </section>

      {/* Main 2-Column Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Quick Entry + Recent Activity */}
        <div className="lg:col-span-5 space-y-6">
          <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between gap-3 mb-4">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Quick Record
              </h2>
              <div className="flex items-center gap-1 p-0.5 bg-slate-100 dark:bg-slate-800 rounded-lg">
                <button
                  type="button"
                  onClick={() => setEntryMode('expense')}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    entryMode === 'expense'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Expense
                </button>
                <button
                  type="button"
                  onClick={() => setEntryMode('income')}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    entryMode === 'income'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  Income
                </button>
              </div>
            </div>

            <form onSubmit={handleQuickSubmit} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="quick-amount"
                    className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
                  >
                    Amount
                  </label>
                  <input
                    id="quick-amount"
                    type="number"
                    step="0.01"
                    min="0.01"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>

                <div>
                  <label
                    htmlFor="quick-date"
                    className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
                  >
                    Date
                  </label>
                  <input
                    id="quick-date"
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  />
                </div>
              </div>

              {entryMode === 'expense' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label
                      htmlFor="quick-category"
                      className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
                    >
                      Category
                    </label>
                    <select
                      id="quick-category"
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    >
                      {categories.map((cat) => (
                        <option key={cat} value={cat}>
                          {cat}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label
                      htmlFor="quick-method"
                      className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
                    >
                      Payment Method
                    </label>
                    <select
                      id="quick-method"
                      value={paymentMethod}
                      onChange={(e) => setPaymentMethod(e.target.value)}
                      className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                    >
                      {PAYMENT_METHODS.map((pm) => (
                        <option key={pm} value={pm}>
                          {pm}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              ) : (
                <div>
                  <label
                    htmlFor="quick-source"
                    className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
                  >
                    Income Source
                  </label>
                  <select
                    id="quick-source"
                    value={source}
                    onChange={(e) => setSource(e.target.value)}
                    className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                  >
                    {INCOME_SOURCES.map((src) => (
                      <option key={src} value={src}>
                        {src}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label
                  htmlFor="quick-note"
                  className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
                >
                  Note / Description (optional)
                </label>
                <input
                  id="quick-note"
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder={
                    entryMode === 'expense'
                      ? 'e.g. Groceries or metro pass'
                      : 'e.g. Monthly salary credit'
                  }
                  className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              {formError && (
                <p className="text-xs font-medium text-rose-600 dark:text-rose-400">
                  {formError}
                </p>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap"
              >
                <Plus className="h-4 w-4" />
                {submitting
                  ? 'Saving...'
                  : entryMode === 'expense'
                  ? 'Add Expense'
                  : 'Add Income'}
              </button>
            </form>
          </section>

          {/* Smart Spending Highlight Card */}
          <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between gap-3 mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                  Spending Forecast
                </h2>
              </div>
              <button
                type="button"
                onClick={() => onNavigateTab('reports')}
                className="text-xs font-medium text-blue-700 dark:text-blue-400 hover:underline whitespace-nowrap"
              >
                Full Insights
              </button>
            </div>
            <div className="grid grid-cols-2 gap-4 py-2 border-y border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-xs text-slate-500 dark:text-slate-400 block">
                  Projected Next Month
                </span>
                <span className="mt-1 font-mono text-base font-semibold text-slate-900 dark:text-white tabular-nums block">
                  {formatCurrency(insights.nextMonthForecast, currency)}
                </span>
              </div>
              <div>
                <span className="text-xs text-slate-500 dark:text-slate-400 block">
                  Daily Burn Rate
                </span>
                <span className="mt-1 font-mono text-base font-semibold text-slate-900 dark:text-white tabular-nums block">
                  {formatCurrency(insights.dailyBurnRate, currency)}/day
                </span>
              </div>
            </div>
            <p className="mt-3 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              {insights.risingCategories.length > 0
                ? `${insights.risingCategories[0].category} spending rose by ${formatCurrency(
                    insights.risingCategories[0].deltaAmount,
                    currency
                  )} (+${insights.risingCategories[0].percentChange}%) compared to last month.`
                : insights.topDriverCategory
                ? `${insights.topDriverCategory} is currently your highest spending category this month.`
                : 'Add transactions across months to unlock category trend comparisons.'}
            </p>
          </section>
        </div>

        {/* Right Column: Donut Chart + Category Budgets */}
        <div className="lg:col-span-7 space-y-6">
          <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between gap-3 mb-4">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                By Category
              </h2>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {getMonthLabel(selectedMonth)}
              </span>
            </div>
            <DonutChart
              data={categorySlices}
              currency={currency}
              emptyActionLabel="Log First Expense"
              onEmptyAction={() => document.getElementById('quick-amount')?.focus()}
            />
          </section>

          <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
            <div className="flex items-center justify-between gap-3 mb-4">
              <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
                Category Budgets
              </h2>
              <button
                type="button"
                onClick={() => onNavigateTab('budgets')}
                className="text-xs font-medium text-blue-700 dark:text-blue-400 hover:underline whitespace-nowrap"
              >
                Manage Limits
              </button>
            </div>

            {categoryBudgets.length === 0 ? (
              <p className="text-sm text-slate-500 dark:text-slate-400 py-4">
                No category expenses or limits configured for {getMonthLabel(selectedMonth)}.
              </p>
            ) : (
              <div className="space-y-3.5">
                {categoryBudgets.map((row) => (
                  <div key={row.category} className="space-y-1.5">
                    <div className="flex items-center justify-between gap-3 text-sm">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="font-medium text-slate-800 dark:text-slate-200 truncate">
                          {row.category}
                        </span>
                        {row.status === 'exceeded' && (
                          <span className="text-xs font-medium text-rose-600 dark:text-rose-400">
                            · Exceeded
                          </span>
                        )}
                        {row.status === 'warning' && (
                          <span className="text-xs font-medium text-amber-600 dark:text-amber-400">
                            · 80%+ Warning
                          </span>
                        )}
                      </div>
                      <span className="font-mono text-xs text-slate-700 dark:text-slate-300 tabular-nums shrink-0">
                        {formatCurrency(row.spent, currency)}
                        {row.limit ? ` / ${formatCurrency(row.limit, currency)}` : ' (No limit)'}
                      </span>
                    </div>
                    {row.limit && (
                      <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-200 ${
                            row.status === 'exceeded'
                              ? 'bg-rose-600'
                              : row.status === 'warning'
                              ? 'bg-amber-500'
                              : 'bg-blue-600 dark:bg-blue-500'
                          }`}
                          style={{ width: `${Math.min(100, row.percentage)}%` }}
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>

      {/* Recent Activity Table */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            Recent Activity ({getMonthLabel(selectedMonth)})
          </h2>
          <div className="flex items-center gap-4 text-xs">
            <button
              type="button"
              onClick={() => onNavigateTab('expenses')}
              className="font-medium text-blue-700 dark:text-blue-400 hover:underline whitespace-nowrap"
            >
              All Expenses
            </button>
            <button
              type="button"
              onClick={() => onNavigateTab('income')}
              className="font-medium text-blue-700 dark:text-blue-400 hover:underline whitespace-nowrap"
            >
              All Income
            </button>
          </div>
        </div>

        {recentActivity.length === 0 ? (
          <div className="px-5 py-10 text-center text-sm text-slate-500 dark:text-slate-400">
            No transactions recorded for {getMonthLabel(selectedMonth)} yet.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-900">
                  <th className="py-2.5 px-5">Date</th>
                  <th className="py-2.5 px-4">Category / Source</th>
                  <th className="py-2.5 px-4">Note</th>
                  <th className="py-2.5 px-4 text-right">Amount</th>
                  <th className="py-2.5 px-5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                {recentActivity.map((item) => (
                  <tr
                    key={`${item.kind}-${item.id}`}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-2.5 px-5 font-mono text-xs text-slate-600 dark:text-slate-400 tabular-nums whitespace-nowrap">
                      {item.date}
                    </td>
                    <td className="py-2.5 px-4 whitespace-nowrap">
                      <span className="font-medium text-slate-900 dark:text-slate-100">
                        {item.label}
                      </span>
                      <span className="mx-1.5 text-slate-300 dark:text-slate-700">·</span>
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        {item.sublabel}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300 max-w-xs truncate">
                      {item.note || '—'}
                    </td>
                    <td
                      className={`py-2.5 px-4 text-right font-mono text-sm font-medium tabular-nums whitespace-nowrap ${
                        item.kind === 'income'
                          ? 'text-emerald-700 dark:text-emerald-400'
                          : 'text-slate-900 dark:text-slate-100'
                      }`}
                    >
                      {item.kind === 'income' ? '+' : '-'}
                      {formatCurrencyExact(item.amount, currency)}
                    </td>
                    <td className="py-2.5 px-5 text-right">
                      <button
                        type="button"
                        onClick={() =>
                          item.kind === 'expense'
                            ? onDeleteExpense(item.id)
                            : onDeleteIncome(item.id)
                        }
                        aria-label={`Delete ${item.label} record`}
                        className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-md transition-colors"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
