import { useState, type FormEvent } from 'react';
import {
  AlertTriangle,
  CalendarClock,
  CheckCircle2,
  Pause,
  Play,
  Plus,
  PiggyBank,
  Trash2,
} from 'lucide-react';
import type {
  ExpenseRecord,
  RecurringFrequency,
  RecurringRule,
  SavingsGoal,
  UserPreferences,
} from '../types/finance';
import {
  calculateExpense,
  computeCategoryBudgets,
  evaluateBudgetStatus,
  formatCurrency,
  getMonthLabel,
  PAYMENT_METHODS,
} from '../utils/calculations';

interface BudgetsAndGoalsViewProps {
  selectedMonth: string;
  preferences: UserPreferences;
  categories: string[];
  expenses: ExpenseRecord[];
  recurringRules: RecurringRule[];
  savingsGoals: SavingsGoal[];
  onSaveBudgetSettings: (input: {
    monthlyBudget: number;
    categoryLimits: Record<string, number>;
  }) => Promise<void>;
  onCreateRecurring: (input: {
    title: string;
    amount: number;
    category: string;
    paymentMethod: string;
    frequency: RecurringFrequency;
    nextDueDate: string;
  }) => Promise<void>;
  onToggleRecurring: (id: string, active: boolean) => Promise<void>;
  onLogRecurring: (id: string, date: string) => Promise<void>;
  onDeleteRecurring: (id: string) => Promise<void>;
  onCreateGoal: (input: {
    title: string;
    targetAmount: number;
    savedAmount: number;
    deadline: string;
  }) => Promise<void>;
  onContributeGoal: (id: string, delta: number) => Promise<void>;
  onDeleteGoal: (id: string) => Promise<void>;
}

export function BudgetsAndGoalsView({
  selectedMonth,
  preferences,
  categories,
  expenses,
  recurringRules,
  savingsGoals,
  onSaveBudgetSettings,
  onCreateRecurring,
  onToggleRecurring,
  onLogRecurring,
  onDeleteRecurring,
  onCreateGoal,
  onContributeGoal,
  onDeleteGoal,
}: BudgetsAndGoalsViewProps) {
  const [monthlyBudgetInput, setMonthlyBudgetInput] = useState(
    String(preferences.monthlyBudget)
  );
  const [selectedCategory, setSelectedCategory] = useState(categories[0] || 'Food');
  const [categoryLimitInput, setCategoryLimitInput] = useState(
    String(preferences.categoryLimits[categories[0] || 'Food'] || '')
  );
  const [budgetSavedMsg, setBudgetSavedMsg] = useState<string | null>(null);

  // Recurring rule form
  const [recTitle, setRecTitle] = useState('');
  const [recAmount, setRecAmount] = useState('');
  const [recCategory, setRecCategory] = useState(categories[0] || 'Bills');
  const [recMethod, setRecMethod] = useState(PAYMENT_METHODS[0]);
  const [recFrequency, setRecFrequency] = useState<RecurringFrequency>('monthly');
  const [recDueDate, setRecDueDate] = useState(`${selectedMonth}-25`);

  // Savings goal form
  const [goalTitle, setGoalTitle] = useState('');
  const [goalTarget, setGoalTarget] = useState('');
  const [goalSaved, setGoalSaved] = useState('0');
  const [goalDeadline, setGoalDeadline] = useState('2027-06-30');
  const [contributionInputs, setContributionInputs] = useState<Record<string, string>>({});

  const currency = preferences.currency;
  const totalSpent = calculateExpense(expenses, selectedMonth);
  const overallEval = evaluateBudgetStatus(totalSpent, preferences.monthlyBudget);
  const categoryBudgets = computeCategoryBudgets(
    expenses,
    preferences.categoryLimits,
    selectedMonth
  );

  async function handleSaveMonthlyBudget(e: FormEvent) {
    e.preventDefault();
    const num = Number(monthlyBudgetInput);
    if (!Number.isFinite(num) || num < 0) return;
    await onSaveBudgetSettings({
      monthlyBudget: num,
      categoryLimits: preferences.categoryLimits,
    });
    setBudgetSavedMsg('Monthly budget updated.');
    setTimeout(() => setBudgetSavedMsg(null), 2500);
  }

  async function handleSaveCategoryLimit(e: FormEvent) {
    e.preventDefault();
    const num = Number(categoryLimitInput);
    const updated = { ...preferences.categoryLimits };
    if (!categoryLimitInput.trim() || num <= 0) {
      delete updated[selectedCategory];
    } else {
      updated[selectedCategory] = num;
    }
    await onSaveBudgetSettings({
      monthlyBudget: preferences.monthlyBudget,
      categoryLimits: updated,
    });
    setBudgetSavedMsg(`Limit updated for ${selectedCategory}.`);
    setTimeout(() => setBudgetSavedMsg(null), 2500);
  }

  async function handleAddRecurring(e: FormEvent) {
    e.preventDefault();
    const num = Number(recAmount);
    if (!recTitle.trim() || !Number.isFinite(num) || num <= 0) return;
    await onCreateRecurring({
      title: recTitle.trim(),
      amount: num,
      category: recCategory,
      paymentMethod: recMethod,
      frequency: recFrequency,
      nextDueDate: recDueDate,
    });
    setRecTitle('');
    setRecAmount('');
  }

  async function handleAddGoal(e: FormEvent) {
    e.preventDefault();
    const target = Number(goalTarget);
    const saved = Number(goalSaved || 0);
    if (!goalTitle.trim() || !Number.isFinite(target) || target <= 0) return;
    await onCreateGoal({
      title: goalTitle.trim(),
      targetAmount: target,
      savedAmount: Math.max(0, saved),
      deadline: goalDeadline,
    });
    setGoalTitle('');
    setGoalTarget('');
    setGoalSaved('0');
  }

  return (
    <div className="space-y-8">
      {/* Module 4: Monthly & Category Budgets */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-5">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              Budget Configuration
            </h2>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Warnings trigger at 80% usage; exceeded alerts appear above 100%.
            </p>
          </div>

          <form onSubmit={handleSaveMonthlyBudget} className="space-y-2.5">
            <label
              htmlFor="cfg-monthly-budget"
              className="block text-xs font-medium text-slate-600 dark:text-slate-400"
            >
              Overall Monthly Spending Limit
            </label>
            <div className="flex gap-2">
              <input
                id="cfg-monthly-budget"
                type="number"
                step="0.01"
                min="0"
                value={monthlyBudgetInput}
                onChange={(e) => setMonthlyBudgetInput(e.target.value)}
                className="flex-1 px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap"
              >
                Save Limit
              </button>
            </div>
          </form>

          <form
            onSubmit={handleSaveCategoryLimit}
            className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2.5"
          >
            <label
              htmlFor="cfg-cat-select"
              className="block text-xs font-medium text-slate-600 dark:text-slate-400"
            >
              Category-Wise Monthly Limit
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <select
                id="cfg-cat-select"
                value={selectedCategory}
                onChange={(e) => {
                  const cat = e.target.value;
                  setSelectedCategory(cat);
                  setCategoryLimitInput(
                    preferences.categoryLimits[cat]
                      ? String(preferences.categoryLimits[cat])
                      : ''
                  );
                }}
                className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              <input
                type="number"
                step="0.01"
                min="0"
                aria-label="Category limit amount"
                value={categoryLimitInput}
                onChange={(e) => setCategoryLimitInput(e.target.value)}
                placeholder="Leave blank to clear"
                className="px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
              />
            </div>
            <div className="flex items-center justify-between gap-2">
              {budgetSavedMsg ? (
                <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
                  {budgetSavedMsg}
                </span>
              ) : (
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  Set 0 or blank to remove a category cap
                </span>
              )}
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 rounded-lg transition-colors whitespace-nowrap"
              >
                Apply Category Cap
              </button>
            </div>
          </form>
        </div>

        <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              Budget Usage ({getMonthLabel(selectedMonth)})
            </h2>
            <span className="font-mono text-xs text-slate-600 dark:text-slate-300 tabular-nums">
              {formatCurrency(totalSpent, currency)} /{' '}
              {formatCurrency(preferences.monthlyBudget, currency)} ({overallEval.percentage}%)
            </span>
          </div>

          <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-200 ${
                overallEval.status === 'exceeded'
                  ? 'bg-rose-600'
                  : overallEval.status === 'warning'
                  ? 'bg-amber-500'
                  : 'bg-emerald-600'
              }`}
              style={{ width: `${Math.min(100, overallEval.percentage)}%` }}
            />
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {categoryBudgets.length === 0 ? (
              <p className="py-6 text-sm text-slate-500 dark:text-slate-400">
                No category budgets or expenses recorded yet for this month.
              </p>
            ) : (
              categoryBudgets.map((row) => (
                <div key={row.category} className="py-3 space-y-1.5">
                  <div className="flex items-center justify-between gap-3 text-sm">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-slate-900 dark:text-slate-100">
                        {row.category}
                      </span>
                      {row.status === 'exceeded' && (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-rose-600 dark:text-rose-400">
                          <AlertTriangle className="h-3.5 w-3.5" />
                          Exceeded ({row.percentage}%)
                        </span>
                      )}
                      {row.status === 'warning' && (
                        <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-600 dark:text-amber-400">
                          <AlertTriangle className="h-3.5 w-3.5" />
                          Warning ({row.percentage}%)
                        </span>
                      )}
                      {row.status === 'healthy' && (
                        <span className="inline-flex items-center gap-1 text-xs text-emerald-700 dark:text-emerald-400">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          On Track ({row.percentage}%)
                        </span>
                      )}
                    </div>
                    <span className="font-mono text-xs text-slate-700 dark:text-slate-300 tabular-nums">
                      {formatCurrency(row.spent, currency)}
                      {row.limit ? ` / ${formatCurrency(row.limit, currency)}` : ' (No limit)'}
                    </span>
                  </div>
                  {row.limit && (
                    <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          row.status === 'exceeded'
                            ? 'bg-rose-600'
                            : row.status === 'warning'
                            ? 'bg-amber-500'
                            : 'bg-emerald-600'
                        }`}
                        style={{ width: `${Math.min(100, row.percentage)}%` }}
                      />
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Future Scope: Recurring Expenses & Bills */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-5">
        <div className="flex items-center gap-2">
          <CalendarClock className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            Recurring Expenses &amp; Subscriptions
          </h2>
        </div>

        <form
          onSubmit={handleAddRecurring}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-2.5"
        >
          <input
            type="text"
            required
            value={recTitle}
            onChange={(e) => setRecTitle(e.target.value)}
            placeholder="Bill title (e.g. Wi-Fi)"
            className="lg:col-span-2 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
          />
          <input
            type="number"
            step="0.01"
            min="0.01"
            required
            value={recAmount}
            onChange={(e) => setRecAmount(e.target.value)}
            placeholder="Amount"
            className="px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
          />
          <select
            value={recCategory}
            onChange={(e) => setRecCategory(e.target.value)}
            className="px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
          >
            {categories.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <div className="flex gap-2">
            <select
              value={recFrequency}
              onChange={(e) => setRecFrequency(e.target.value as RecurringFrequency)}
              className="flex-1 px-2.5 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
            >
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
              <option value="yearly">Yearly</option>
            </select>
            <input
              type="date"
              required
              value={recDueDate}
              onChange={(e) => setRecDueDate(e.target.value)}
              className="flex-1 px-2.5 py-2 text-xs font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
            />
          </div>
          <button
            type="submit"
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap"
          >
            <Plus className="h-3.5 w-3.5" />
            Add Bill
          </button>
        </form>

        {recurringRules.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400">
            No recurring bills configured yet. Add rent, utilities, or subscriptions above.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                  <th className="py-2 pr-4">Bill</th>
                  <th className="py-2 px-4">Cadence &amp; Next Due</th>
                  <th className="py-2 px-4 text-right">Amount</th>
                  <th className="py-2 pl-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                {recurringRules.map((rule) => (
                  <tr key={rule.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-2.5 pr-4">
                      <span className="font-medium text-slate-900 dark:text-slate-100">
                        {rule.title}
                      </span>
                      <span className="mx-1.5 text-slate-300 dark:text-slate-700">·</span>
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        {rule.category} · {rule.active ? 'Active' : 'Paused'}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 font-mono text-xs text-slate-600 dark:text-slate-400 tabular-nums whitespace-nowrap">
                      {rule.frequency} · Next: {rule.nextDueDate}
                    </td>
                    <td className="py-2.5 px-4 text-right font-mono font-medium text-slate-900 dark:text-slate-100 tabular-nums whitespace-nowrap">
                      {formatCurrency(rule.amount, currency)}
                    </td>
                    <td className="py-2.5 pl-4 text-right whitespace-nowrap space-x-2">
                      <button
                        type="button"
                        onClick={() => onLogRecurring(rule.id, `${selectedMonth}-18`)}
                        className="px-2.5 py-1 text-xs font-medium text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/60 hover:bg-blue-100 dark:hover:bg-blue-900/60 rounded-md transition-colors"
                      >
                        Log Expense
                      </button>
                      <button
                        type="button"
                        onClick={() => onToggleRecurring(rule.id, !rule.active)}
                        aria-label={rule.active ? 'Pause bill' : 'Resume bill'}
                        className="p-1.5 text-slate-400 hover:text-slate-800 dark:hover:text-slate-200"
                      >
                        {rule.active ? (
                          <Pause className="h-3.5 w-3.5" />
                        ) : (
                          <Play className="h-3.5 w-3.5" />
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteRecurring(rule.id)}
                        aria-label={`Delete ${rule.title}`}
                        className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* Future Scope: Savings Goals Tracker */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-5">
        <div className="flex items-center gap-2">
          <PiggyBank className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            Savings Goals Tracker
          </h2>
        </div>

        <form
          onSubmit={handleAddGoal}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5"
        >
          <input
            type="text"
            required
            value={goalTitle}
            onChange={(e) => setGoalTitle(e.target.value)}
            placeholder="Goal name (e.g. Emergency Fund)"
            className="lg:col-span-2 px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
          />
          <input
            type="number"
            step="0.01"
            min="1"
            required
            value={goalTarget}
            onChange={(e) => setGoalTarget(e.target.value)}
            placeholder="Target amount"
            className="px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
          />
          <input
            type="number"
            step="0.01"
            min="0"
            value={goalSaved}
            onChange={(e) => setGoalSaved(e.target.value)}
            placeholder="Saved so far"
            className="px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
          />
          <div className="flex gap-2">
            <input
              type="date"
              value={goalDeadline}
              onChange={(e) => setGoalDeadline(e.target.value)}
              className="flex-1 px-2.5 py-2 text-xs font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
            />
            <button
              type="submit"
              className="px-3.5 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap"
            >
              Add Goal
            </button>
          </div>
        </form>

        {savingsGoals.length === 0 ? (
          <p className="text-sm text-slate-500 dark:text-slate-400">
            No savings goals yet. Set a target above to monitor your progress.
          </p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {savingsGoals.map((goal) => {
              const pct = Math.min(
                100,
                Math.round((goal.savedAmount / Math.max(1, goal.targetAmount)) * 1000) / 10
              );
              const remaining = Math.max(0, goal.targetAmount - goal.savedAmount);
              const deltaVal = contributionInputs[goal.id] || '';

              return (
                <div
                  key={goal.id}
                  className="p-4 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                        {goal.title}
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums mt-0.5">
                        Target date: {goal.deadline} · {pct}% reached
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => onDeleteGoal(goal.id)}
                      aria-label={`Delete ${goal.title}`}
                      className="p-1 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-600 dark:bg-emerald-500 rounded-full transition-all duration-200"
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  <div className="flex items-center justify-between text-xs font-mono tabular-nums text-slate-700 dark:text-slate-300">
                    <span>Saved: {formatCurrency(goal.savedAmount, currency)}</span>
                    <span>
                      {remaining > 0
                        ? `Left: ${formatCurrency(remaining, currency)}`
                        : 'Target Reached'}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="number"
                      step="1"
                      min="1"
                      value={deltaVal}
                      onChange={(e) =>
                        setContributionInputs((prev) => ({
                          ...prev,
                          [goal.id]: e.target.value,
                        }))
                      }
                      placeholder="Amount"
                      className="flex-1 px-2.5 py-1.5 text-xs font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        const val = Number(deltaVal);
                        if (val > 0) {
                          await onContributeGoal(goal.id, val);
                          setContributionInputs((prev) => ({ ...prev, [goal.id]: '' }));
                        }
                      }}
                      className="px-3 py-1.5 text-xs font-medium text-white bg-emerald-700 hover:bg-emerald-800 rounded-lg transition-colors whitespace-nowrap"
                    >
                      + Add Funds
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
