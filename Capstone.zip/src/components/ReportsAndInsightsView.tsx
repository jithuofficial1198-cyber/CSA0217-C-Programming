import { useState } from 'react';
import { TrendingUp, Sparkles } from 'lucide-react';
import type { CurrencyCode, ExpenseRecord, IncomeRecord } from '../types/finance';
import {
  calculateBalance,
  calculateExpense,
  calculateIncome,
  computeInsightsAndForecast,
  formatCurrency,
  getMonthLabel,
  getShortMonthLabel,
  groupExpensesByCategory,
} from '../utils/calculations';
import { ComparisonBarChart, DonutChart, type ComparisonBarDatum } from './Charts';

interface ReportsAndInsightsViewProps {
  selectedMonth: string;
  currency: CurrencyCode;
  incomes: IncomeRecord[];
  expenses: ExpenseRecord[];
}

export function ReportsAndInsightsView({
  selectedMonth,
  currency,
  incomes,
  expenses,
}: ReportsAndInsightsViewProps) {
  const [periodView, setPeriodView] = useState<'daily' | 'monthly' | 'yearly'>('monthly');

  const insights = computeInsightsAndForecast(incomes, expenses, selectedMonth);
  const categorySlices = groupExpensesByCategory(expenses, selectedMonth);

  // Build ComparisonBarChart data based on selected granularity
  const chartData: ComparisonBarDatum[] = (() => {
    if (periodView === 'daily') {
      const days = new Set<string>();
      incomes
        .filter((i) => i.date.startsWith(selectedMonth))
        .forEach((i) => days.add(i.date));
      expenses
        .filter((e) => e.date.startsWith(selectedMonth))
        .forEach((e) => days.add(e.date));

      return Array.from(days)
        .sort()
        .map((day) => ({
          label: day.slice(8, 10),
          income: calculateIncome(incomes, day),
          expense: calculateExpense(expenses, day),
        }));
    }

    if (periodView === 'yearly') {
      const years = new Set<string>();
      incomes.forEach((i) => years.add(i.date.slice(0, 4)));
      expenses.forEach((e) => years.add(e.date.slice(0, 4)));

      return Array.from(years)
        .sort()
        .map((yr) => ({
          label: yr,
          income: calculateIncome(incomes, yr),
          expense: calculateExpense(expenses, yr),
        }));
    }

    // Monthly default
    const months = new Set<string>();
    incomes.forEach((i) => months.add(i.date.slice(0, 7)));
    expenses.forEach((e) => months.add(e.date.slice(0, 7)));

    return Array.from(months)
      .sort()
      .map((mk) => ({
        label: getShortMonthLabel(mk),
        income: calculateIncome(incomes, mk),
        expense: calculateExpense(expenses, mk),
      }));
  })();

  const allMonths = Array.from(
    new Set([
      ...incomes.map((i) => i.date.slice(0, 7)),
      ...expenses.map((e) => e.date.slice(0, 7)),
    ])
  )
    .sort()
    .reverse();

  return (
    <div className="space-y-6">
      {/* Future Scope: Smart Spending Insights & Predictions */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              Smart Spending Insights &amp; Expense Prediction
            </h2>
          </div>
          <span className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
            {insights.monthsAnalyzed} months analysed
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Projected End-of-Month Spend
            </span>
            <p className="mt-1.5 font-mono text-xl font-semibold text-slate-900 dark:text-white tabular-nums">
              {formatCurrency(insights.projectedMonthEndSpend, currency)}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
              Burn rate: {formatCurrency(insights.dailyBurnRate, currency)} / day
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Next Month Estimate (Weighted Avg)
            </span>
            <p className="mt-1.5 font-mono text-xl font-semibold text-blue-700 dark:text-blue-400 tabular-nums">
              {formatCurrency(insights.nextMonthForecast, currency)}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              Based on recent transaction history
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Top Spending Driver
            </span>
            <p className="mt-1.5 font-display text-xl font-semibold text-slate-900 dark:text-white">
              {insights.topDriverCategory || 'No Data'}
            </p>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {insights.savingsRatePercent !== null
                ? `Savings rate: ${insights.savingsRatePercent}%`
                : 'Log income to view savings rate'}
            </p>
          </div>
        </div>

        <div className="pt-2">
          <h3 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
            Categories Where Spending Increased vs. Prior Month
          </h3>
          {insights.risingCategories.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-slate-400">
              No category spending increases detected for {getMonthLabel(selectedMonth)} compared to the previous month.
            </p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {insights.risingCategories.map((item) => (
                <div
                  key={item.category}
                  className="flex items-center justify-between gap-3 px-3.5 py-2.5 border border-amber-200 dark:border-amber-800/80 bg-amber-50/70 dark:bg-amber-950/30 rounded-lg"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <TrendingUp className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400 shrink-0" />
                    <span className="text-xs font-medium text-slate-900 dark:text-slate-100 truncate">
                      {item.category}
                    </span>
                  </div>
                  <span className="font-mono text-xs font-medium text-amber-700 dark:text-amber-300 tabular-nums shrink-0">
                    +{formatCurrency(item.deltaAmount, currency)} (+{item.percentChange}%)
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Module 5: Bar Chart Comparison + Category Donut */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <section className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              Income vs. Expenses Comparison
            </h2>
            <div className="flex items-center gap-1 p-0.5 bg-slate-100 dark:bg-slate-800 rounded-lg">
              {(['daily', 'monthly', 'yearly'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setPeriodView(tab)}
                  className={`px-3 py-1 text-xs font-medium rounded-md capitalize transition-colors whitespace-nowrap ${
                    periodView === tab
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>
          <ComparisonBarChart data={chartData} currency={currency} />
        </section>

        <section className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white mb-4">
            Category Share ({getMonthLabel(selectedMonth)})
          </h2>
          <DonutChart data={categorySlices} currency={currency} />
        </section>
      </div>

      {/* Monthly Statement Table */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800">
          <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
            Monthly Financial Summary
          </h2>
        </div>
        {allMonths.length === 0 ? (
          <p className="px-5 py-10 text-center text-sm text-slate-500 dark:text-slate-400">
            Record income and expenses to generate monthly financial statements.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-900">
                  <th className="py-2.5 px-5">Month</th>
                  <th className="py-2.5 px-4 text-right">Total Income</th>
                  <th className="py-2.5 px-4 text-right">Total Expenses</th>
                  <th className="py-2.5 px-5 text-right">Net Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                {allMonths.map((mk) => {
                  const inc = calculateIncome(incomes, mk);
                  const exp = calculateExpense(expenses, mk);
                  const bal = calculateBalance(inc, exp);
                  return (
                    <tr key={mk} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-2.5 px-5 font-medium text-slate-900 dark:text-slate-100">
                        {getMonthLabel(mk)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                        {formatCurrency(inc, currency)}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-900 dark:text-slate-100">
                        {formatCurrency(exp, currency)}
                      </td>
                      <td
                        className={`py-2.5 px-5 text-right font-mono font-medium tabular-nums ${
                          bal >= 0
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : 'text-rose-600 dark:text-rose-400'
                        }`}
                      >
                        {formatCurrency(bal, currency)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
