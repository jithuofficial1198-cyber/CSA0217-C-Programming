import { useState, type FormEvent } from 'react';
import { Pencil, Plus, Trash2, X } from 'lucide-react';
import type { CurrencyCode, IncomeRecord } from '../types/finance';
import {
  calculateIncome,
  formatCurrency,
  formatCurrencyExact,
  getMonthLabel,
  INCOME_SOURCES,
} from '../utils/calculations';

interface IncomeViewProps {
  selectedMonth: string;
  currency: CurrencyCode;
  incomes: IncomeRecord[];
  onAddIncome: (input: {
    amount: number;
    source: string;
    description: string;
    date: string;
  }) => Promise<void>;
  onUpdateIncome: (
    id: string,
    input: Partial<Pick<IncomeRecord, 'amount' | 'source' | 'description' | 'date'>>
  ) => Promise<void>;
  onDeleteIncome: (id: string) => Promise<void>;
}

export function IncomeView({
  selectedMonth,
  currency,
  incomes,
  onAddIncome,
  onUpdateIncome,
  onDeleteIncome,
}: IncomeViewProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [amount, setAmount] = useState('');
  const [source, setSource] = useState(INCOME_SOURCES[0]);
  const [description, setDescription] = useState('');
  const [date, setDate] = useState(`${selectedMonth}-01`);
  const [filterSource, setFilterSource] = useState('ALL');
  const [scope, setScope] = useState<'month' | 'all'>('month');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const selectedYear = selectedMonth.slice(0, 4);
  const todayStr = new Date().toISOString().slice(0, 10);

  const dailyTotal = calculateIncome(incomes, todayStr);
  const monthlyTotal = calculateIncome(incomes, selectedMonth);
  const yearlyTotal = calculateIncome(incomes, selectedYear);

  const filtered = incomes.filter((item) => {
    if (scope === 'month' && !item.date.startsWith(selectedMonth)) return false;
    if (filterSource !== 'ALL' && item.source !== filterSource) return false;
    return true;
  });

  function startEdit(record: IncomeRecord) {
    setEditingId(record.id);
    setAmount(String(record.amount));
    setSource(record.source);
    setDescription(record.description);
    setDate(record.date);
    setError(null);
  }

  function resetForm() {
    setEditingId(null);
    setAmount('');
    setSource(INCOME_SOURCES[0]);
    setDescription('');
    setDate(`${selectedMonth}-01`);
    setError(null);
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    const num = Number(amount);
    if (!Number.isFinite(num) || num <= 0) {
      setError('Income amount must be greater than zero.');
      return;
    }
    setSubmitting(true);
    try {
      if (editingId) {
        await onUpdateIncome(editingId, {
          amount: num,
          source,
          description,
          date,
        });
      } else {
        await onAddIncome({
          amount: num,
          source,
          description,
          date,
        });
      }
      resetForm();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save income record.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="space-y-6">
      {/* Income Summaries (Daily / Monthly / Yearly) */}
      <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Today ({todayStr})
          </span>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 dark:text-white tabular-nums">
            {formatCurrency(dailyTotal, currency)}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Monthly ({getMonthLabel(selectedMonth)})
          </span>
          <p className="mt-2 font-mono text-2xl font-semibold text-emerald-700 dark:text-emerald-400 tabular-nums">
            {formatCurrency(monthlyTotal, currency)}
          </p>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Yearly ({selectedYear})
          </span>
          <p className="mt-2 font-mono text-2xl font-semibold text-slate-900 dark:text-white tabular-nums">
            {formatCurrency(yearlyTotal, currency)}
          </p>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Add / Edit Income Form */}
        <section className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              {editingId ? 'Edit Income Record' : 'Add Income Source'}
            </h2>
            {editingId && (
              <button
                type="button"
                onClick={resetForm}
                className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 inline-flex items-center gap-1"
              >
                <X className="h-3.5 w-3.5" />
                Cancel
              </button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-3.5">
            <div>
              <label
                htmlFor="inc-amount"
                className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
              >
                Amount
              </label>
              <input
                id="inc-amount"
                type="number"
                step="0.01"
                min="0.01"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label
                htmlFor="inc-source"
                className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
              >
                Source
              </label>
              <select
                id="inc-source"
                value={source}
                onChange={(e) => setSource(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                {INCOME_SOURCES.map((src) => (
                  <option key={src} value={src}>
                    {src}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="inc-date"
                className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
              >
                Date Received
              </label>
              <input
                id="inc-date"
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono tabular-nums bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div>
              <label
                htmlFor="inc-desc"
                className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
              >
                Description
              </label>
              <input
                id="inc-desc"
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="e.g. Monthly salary or freelance milestone"
                className="w-full px-3 py-2 text-sm bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            {error && (
              <p className="text-xs font-medium text-rose-600 dark:text-rose-400">{error}</p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 disabled:opacity-60 rounded-lg transition-colors whitespace-nowrap"
            >
              <Plus className="h-4 w-4" />
              {submitting ? 'Saving...' : editingId ? 'Update Income' : 'Record Income'}
            </button>
          </form>
        </section>

        {/* Income Ledger */}
        <section className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
            <h2 className="font-display text-base font-semibold text-slate-900 dark:text-white">
              Income Records
            </h2>
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex items-center gap-1 p-0.5 bg-slate-100 dark:bg-slate-800 rounded-lg">
                <button
                  type="button"
                  onClick={() => setScope('month')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    scope === 'month'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {getMonthLabel(selectedMonth)}
                </button>
                <button
                  type="button"
                  onClick={() => setScope('all')}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                    scope === 'all'
                      ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400'
                  }`}
                >
                  All Dates
                </button>
              </div>
              <select
                aria-label="Filter by income source"
                value={filterSource}
                onChange={(e) => setFilterSource(e.target.value)}
                className="px-2.5 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200"
              >
                <option value="ALL">All Sources</option>
                {INCOME_SOURCES.map((src) => (
                  <option key={src} value={src}>
                    {src}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {filtered.length === 0 ? (
            <div className="px-5 py-12 text-center">
              <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                No income entries match this view
              </p>
              <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
                Add salary, allowance, part-time earnings, or switch to All Dates.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400 bg-slate-50/70 dark:bg-slate-900">
                    <th className="py-2.5 px-5">Date</th>
                    <th className="py-2.5 px-4">Source</th>
                    <th className="py-2.5 px-4">Description</th>
                    <th className="py-2.5 px-4 text-right">Amount</th>
                    <th className="py-2.5 px-5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-sm">
                  {filtered.map((item) => (
                    <tr
                      key={item.id}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-2.5 px-5 font-mono text-xs text-slate-600 dark:text-slate-400 tabular-nums whitespace-nowrap">
                        {item.date}
                      </td>
                      <td className="py-2.5 px-4 font-medium text-slate-900 dark:text-slate-100 whitespace-nowrap">
                        {item.source}
                      </td>
                      <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300 max-w-xs truncate">
                        {item.description || '—'}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono font-medium text-emerald-700 dark:text-emerald-400 tabular-nums whitespace-nowrap">
                        +{formatCurrencyExact(item.amount, currency)}
                      </td>
                      <td className="py-2.5 px-5 text-right whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => startEdit(item)}
                          aria-label={`Edit ${item.source} income`}
                          className="p-1.5 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 rounded-md transition-colors"
                        >
                          <Pencil className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteIncome(item.id)}
                          aria-label={`Delete ${item.source} income`}
                          className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-md transition-colors ml-1"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
