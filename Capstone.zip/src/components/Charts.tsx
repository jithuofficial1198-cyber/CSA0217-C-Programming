import { useState } from 'react';
import type { CurrencyCode } from '../types/finance';
import { formatCurrency } from '../utils/calculations';

interface DonutSlice {
  category: string;
  amount: number;
  color: string;
}

interface DonutChartProps {
  data: DonutSlice[];
  currency: CurrencyCode;
  emptyActionLabel?: string;
  onEmptyAction?: () => void;
}

export function DonutChart({
  data,
  currency,
  emptyActionLabel,
  onEmptyAction,
}: DonutChartProps) {
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);
  const total = data.reduce((sum, item) => sum + item.amount, 0);

  if (data.length === 0 || total <= 0) {
    return (
      <div className="flex flex-col items-center justify-center py-10 text-center">
        <div className="h-32 w-32 rounded-full border-8 border-slate-100 dark:border-slate-800 flex items-center justify-center mb-4">
          <span className="font-mono text-xs text-slate-400 dark:text-slate-500 tabular-nums">
            {formatCurrency(0, currency)}
          </span>
        </div>
        <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
          No expenses recorded for this period
        </p>
        <p className="mt-1 text-xs text-slate-500 dark:text-slate-400 max-w-xs">
          Category distribution appears automatically once you log an expense.
        </p>
        {emptyActionLabel && onEmptyAction && (
          <button
            type="button"
            onClick={onEmptyAction}
            className="mt-4 px-3.5 py-2 text-xs font-medium text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors whitespace-nowrap"
          >
            {emptyActionLabel}
          </button>
        )}
      </div>
    );
  }

  const size = 210;
  const center = size / 2;
  const radius = 78;
  const strokeWidth = 30;
  const circumference = 2 * Math.PI * radius;

  let cumulativeFraction = 0;
  const activeSlice = data.find((d) => d.category === hoveredCategory) || null;

  return (
    <div className="flex flex-col sm:flex-row items-center gap-6">
      <div className="relative shrink-0" style={{ width: size, height: size }}>
        <svg
          width={size}
          height={size}
          viewBox={`0 0 ${size} ${size}`}
          className="-rotate-90"
          role="img"
          aria-label="Category spending donut chart"
        >
          <circle
            cx={center}
            cy={center}
            r={radius}
            fill="none"
            stroke="currentColor"
            strokeWidth={strokeWidth}
            className="text-slate-100 dark:text-slate-800"
          />
          {data.map((slice) => {
            const fraction = slice.amount / total;
            const dashLength = Math.max(fraction * circumference - 1.5, 0);
            const dashOffset = -cumulativeFraction * circumference;
            cumulativeFraction += fraction;
            const isHovered = hoveredCategory === slice.category;
            const dimmed = hoveredCategory !== null && !isHovered;

            return (
              <circle
                key={slice.category}
                cx={center}
                cy={center}
                r={radius}
                fill="none"
                stroke={slice.color}
                strokeWidth={isHovered ? strokeWidth + 4 : strokeWidth}
                strokeDasharray={`${dashLength} ${circumference}`}
                strokeDashoffset={dashOffset}
                className="transition-all duration-150 cursor-pointer"
                style={{ opacity: dimmed ? 0.35 : 1 }}
                onMouseEnter={() => setHoveredCategory(slice.category)}
                onMouseLeave={() => setHoveredCategory(null)}
              />
            );
          })}
        </svg>

        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center px-4">
          <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 truncate max-w-[110px]">
            {activeSlice ? activeSlice.category : 'Total Spent'}
          </span>
          <span className="mt-0.5 font-mono text-sm font-semibold text-slate-900 dark:text-slate-100 tabular-nums">
            {formatCurrency(activeSlice ? activeSlice.amount : total, currency)}
          </span>
          {activeSlice && (
            <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 tabular-nums">
              {((activeSlice.amount / total) * 100).toFixed(1)}%
            </span>
          )}
        </div>
      </div>

      <div className="w-full space-y-2 min-w-0">
        {data.map((slice) => {
          const pct = ((slice.amount / total) * 100).toFixed(1);
          const isHovered = hoveredCategory === slice.category;
          return (
            <div
              key={slice.category}
              onMouseEnter={() => setHoveredCategory(slice.category)}
              onMouseLeave={() => setHoveredCategory(null)}
              className={`flex items-center justify-between gap-3 px-2.5 py-1.5 rounded-md transition-colors cursor-default ${
                isHovered
                  ? 'bg-slate-100 dark:bg-slate-800'
                  : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
              }`}
            >
              <div className="flex items-center gap-2.5 min-w-0">
                <span
                  className="h-2.5 w-2.5 rounded-xs shrink-0"
                  style={{ backgroundColor: slice.color }}
                />
                <span className="text-sm text-slate-700 dark:text-slate-200 truncate">
                  {slice.category}
                </span>
              </div>
              <div className="flex items-center gap-2.5 shrink-0 font-mono text-xs tabular-nums">
                <span className="text-slate-500 dark:text-slate-400">{pct}%</span>
                <span className="font-medium text-slate-900 dark:text-slate-100">
                  {formatCurrency(slice.amount, currency)}
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export interface ComparisonBarDatum {
  label: string;
  income: number;
  expense: number;
}

interface ComparisonBarChartProps {
  data: ComparisonBarDatum[];
  currency: CurrencyCode;
}

export function ComparisonBarChart({ data, currency }: ComparisonBarChartProps) {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  if (data.length === 0) {
    return (
      <div className="py-12 text-center text-sm text-slate-500 dark:text-slate-400">
        No transactions found for the selected timeframe.
      </div>
    );
  }

  const maxValue = Math.max(
    100,
    ...data.flatMap((d) => [d.income, d.expense])
  );

  const chartHeight = 220;
  const barGroupWidth = Math.max(48, Math.min(84, Math.floor(620 / data.length)));
  const svgWidth = Math.max(360, data.length * barGroupWidth + 48);

  return (
    <div className="w-full overflow-x-auto">
      <div className="flex items-center justify-between gap-4 mb-4">
        <div className="flex items-center gap-5 text-xs text-slate-600 dark:text-slate-300">
          <span className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-xs bg-emerald-600 dark:bg-emerald-500" />
            Income
          </span>
          <span className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-xs bg-blue-600 dark:bg-blue-500" />
            Expenses
          </span>
        </div>
        {hoveredIdx !== null && data[hoveredIdx] && (
          <div className="font-mono text-xs text-slate-700 dark:text-slate-200 tabular-nums">
            <span>{data[hoveredIdx].label}</span>
            <span className="mx-2 text-slate-400">·</span>
            <span className="text-emerald-700 dark:text-emerald-400">
              In: {formatCurrency(data[hoveredIdx].income, currency)}
            </span>
            <span className="mx-2 text-slate-400">/</span>
            <span className="text-blue-700 dark:text-blue-400">
              Out: {formatCurrency(data[hoveredIdx].expense, currency)}
            </span>
          </div>
        )}
      </div>

      <svg
        viewBox={`0 0 ${svgWidth} ${chartHeight + 36}`}
        className="w-full min-w-[360px] h-64 overflow-visible"
        role="img"
        aria-label="Income versus expense comparison bar chart"
      >
        {[0.25, 0.5, 0.75, 1].map((tick) => {
          const y = chartHeight - tick * (chartHeight - 16);
          return (
            <line
              key={tick}
              x1={16}
              x2={svgWidth - 16}
              y1={y}
              y2={y}
              stroke="currentColor"
              strokeDasharray="3 3"
              className="text-slate-200 dark:text-slate-800"
            />
          );
        })}
        <line
          x1={16}
          x2={svgWidth - 16}
          y1={chartHeight}
          y2={chartHeight}
          stroke="currentColor"
          className="text-slate-300 dark:text-slate-700"
        />

        {data.map((item, idx) => {
          const groupX = 28 + idx * barGroupWidth;
          const barWidth = Math.min(18, Math.floor((barGroupWidth - 16) / 2));
          const incomeH = (item.income / maxValue) * (chartHeight - 20);
          const expenseH = (item.expense / maxValue) * (chartHeight - 20);
          const isHovered = hoveredIdx === idx;

          return (
            <g
              key={item.label}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              className="cursor-pointer"
            >
              <rect
                x={groupX - 4}
                y={8}
                width={barGroupWidth - 4}
                height={chartHeight - 8}
                rx={6}
                className={`transition-colors ${
                  isHovered
                    ? 'fill-slate-100/80 dark:fill-slate-800/60'
                    : 'fill-transparent'
                }`}
              />
              <rect
                x={groupX + 2}
                y={chartHeight - incomeH}
                width={barWidth}
                height={Math.max(incomeH, item.income > 0 ? 3 : 0)}
                rx={3}
                className="fill-emerald-600 dark:fill-emerald-500 transition-opacity"
                style={{ opacity: hoveredIdx !== null && !isHovered ? 0.55 : 1 }}
              />
              <rect
                x={groupX + barWidth + 6}
                y={chartHeight - expenseH}
                width={barWidth}
                height={Math.max(expenseH, item.expense > 0 ? 3 : 0)}
                rx={3}
                className="fill-blue-600 dark:fill-blue-500 transition-opacity"
                style={{ opacity: hoveredIdx !== null && !isHovered ? 0.55 : 1 }}
              />
              <text
                x={groupX + barWidth + 4}
                y={chartHeight + 20}
                textAnchor="middle"
                className="fill-slate-500 dark:fill-slate-400 text-[11px] font-mono"
              >
                {item.label}
              </text>
            </g>
          );
        })}
      </svg>
    </div>
  );
}
